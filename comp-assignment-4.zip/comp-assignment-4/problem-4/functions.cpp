#include<math.h>
#include<iostream>
#include<iomanip>
#include<time.h>

using namespace std;

double func1(double x, double y)
{
    return 1/(1-x*y);
}

double func2(double x1, double x2,double x3 , double x4,double k)
{   
    double w= k*x1*x2*x3*x4;
    return ( k*cos(w) - 7*k*w*sin(w) - 6*k*w*w*cos(w) + k*w*w*w*sin(w)    );
}


double monte_carlo (int nop ,double (*func)(double,double))
{
    double sum=0,x,y;

    for(int i=0;i<nop;i++)
    {
        x = double(rand())/double(RAND_MAX);
        y = double(rand())/double(RAND_MAX);
        sum = sum + func(x,y);             
    }
return sum/nop;
}

double monte_carlo (int nop ,double (*func)(double,double,double,double,double) ,double k)
{
    double sum=0,x1,x2,x3,x4;

    for(int i=0;i<nop;i++)
    {
        x1 = double(rand())/double(RAND_MAX);
        x2 = double(rand())/double(RAND_MAX);
        x3 = double(rand())/double(RAND_MAX);
        x4 = double(rand())/double(RAND_MAX);

        sum = sum + func(x1,x2,x3,x4,k);             
    }
return sum/nop;
}
