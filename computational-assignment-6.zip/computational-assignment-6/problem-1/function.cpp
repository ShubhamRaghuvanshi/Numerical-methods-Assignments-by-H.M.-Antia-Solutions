#include<iostream>
#include<iomanip>
#include<math.h>
#include"polyl1.c"
#include "simpl1.c"

using namespace std;



double* thecoefficientsl1(double *x,double *f,double *sigma,int n,int m,double &chi1){
  double *coeff = new double [m+1];
  polyl1(m-1,n,coeff,x,f,1e-10,&chi1);
  return coeff;
}


double func (double x, int q)
{
    srand(rand());
    switch (q)
    {
        case 1: return (231.0*x*x*x*x*x*x - 315.0*x*x*x*x + 105.0*x*x - 5.0 + ((1.0*rand()/RAND_MAX) - 0.5)*0.01);
        
        case 2: return (231.0*x*x*x*x*x*x - 315.0*x*x*x*x + 105.0*x*x - 5.0 + 1e-5/((1.0*rand()/RAND_MAX)) );

        case 3: return (231.0*x*x*x*x*x*x - 315.0*x*x*x*x + 105.0*x*x - 5.0) ;
    }
}
    
void print(double *a , int row , int col)
{
    for(int i=0;i<row;i++)
    {
        for(int j=0;j<col;j++)
        {
            cout<<setw(10)<<a[i*col+j];   
        }cout<<endl;
    }   cout<<endl<<endl;
}


int matmul( double *a, double *b,double *c ,int rowa , int cola , int rowb , int colb )
{
    if (cola!=rowb)
    {
     cout<<"    DIMENTION MISMATCH  "<<endl; 
     return 123; 
    }    
    for(int i=0;i<rowa;i++)
    {
        for(int k=0;k<colb;k++)
        {   c[i*cola + k]=0;
            for(int j=0;j<cola;j++)
            {
                 c[i*cola+k] = c[i*cola+k] + a[i*cola+j]*b[j*colb+k];
            }
        }
    }    
    return 1;
}



double* backwardsub(double **mat,double *matb,int N){
    
  double *sol;
  sol = new double [N];
  for(int i=0;i<N;i++)
    sol[i] = 0;
  for(int i=N-1;i>=0;i--){
    double rhs=0;
    for(int j=N-1;j>i;j--){
      rhs+=mat[i][j]*sol[j];
    }
    sol[i] = (matb[i]-rhs)/mat[i][i];
  }

  return sol;
}

double *gausselimination(double *a,double *x,int N) {
  double **mat,*matb;
  matb = new double [N];
  mat = new double *[N];
  for(int i=0;i<N;i++)
    mat[i] = new double [N];
  for(int i=0;i<N;i++){
    for(int j=0;j<N;j++)
      mat[i][j]=a[i*N+j];
    matb[i]=x[i];
  }
  
    double *sol;
    sol = new double [N];
    for(int i=0;i<N;i++){
    //pivoting code begins
    double temp;
    int tempi;
    temp=mat[i][i];
    tempi=i;
    for(int j=N-1;j>=i;j--){
       if(abs(mat[j][i]) > abs(temp)){
          tempi=j;
          temp = mat[j][i];
      }
    }
    for(int k=0;k<N;k++){
      swap(mat[tempi][k],mat[i][k]);
    }
    swap(matb[tempi],matb[i]);
       for(int j=N-1;j>i;j--){
      double factor;
      factor=mat[j][i]/mat[i][i];
      for(int k=0;k<N;k++){
        mat[j][k] -= mat[i][k]*factor;
      }
      matb[j]-=matb[i]*factor;
    }
    
     }
     sol = backwardsub(mat,matb,N);
    
   for(int l=N-1;l>=0;l--){
    delete [] mat[l];
  }
  delete []mat;
  delete []matb;
  
  return sol;
}

 


void chisq( double (f (double , int )) , int n , int m ,int q, int part)
{
    double g[n][m] , b[n] , x=0.0 , h = 1.0/double(n-1) ,*a ,c[m][m] ,gtb[m] = {0};
    double mean[m] ={0}, var[m] ={0} , delsq=0,chisq=0 ,F=0;

    for(int i=1;i<=n;i++)   //G matrix
    {
        for(int j=1;j<=m;j++)
        {
              g[i-1][j-1] = pow(x,j-1);
        }  
        x = x +h; 
    } 
    
    for(int i=0;i<m;i++)  //C = G'G
    {
        for(int j=0;j<m;j++)
        {   c[i][j]=0;    
            for(int k=0;k<n;k++)
            {
                c[i][j] = g[k][i]*g[k][j] +c[i][j];     
            }  
        }
    }    

    if(part==1)
    {
            x=0.0;
            for(int i=1;i<=n;i++)
            {
                b[i-1] = f(x,q);
                x = x+h;
            }
            for(int i=0;i<m;i++)   //GTB = G'B
            {   gtb[i]=0;
                for(int j=0;j<n;j++)
                {
                    gtb[i] = g[j][i]*b[j] +gtb[i];
                }   
            }

           a = gausselimination(*c ,gtb,m ); //SOlving for coefficients a
            for(int i=0;i<m;i++)
            {
                mean[i] = mean[i] + a[i];
                var[i] = mean[i] + a[i]*a[i];
            }

            x = 0.0;delsq=0.0;chisq=0.0;h = 1.0/double(n-1);
            for(int i=0;i<n;i++)
            {   F=0.0;
                for(int j=1;j<=m;j++)
                {  F = a[j-1]*pow(x,j-1) +F;}                 
                 delsq = delsq + (f(x,1) - F)*( f(x,1)-F );  
                 chisq = chisq +  (f(x,q) - F)*( f(x,q)-F );
                x = x+h;
            }    
            cout<<setw(20)<<delsq<<setw(20)<<chisq<<endl;
    } 

    if(part ==2)   // N==6 PART OF THE PROBLEM
    {
         for(int itr=0;itr<100;itr++)
         {
            x=0.0;
            for(int i=1;i<=n;i++)
            {
                b[i-1] = f(x,q);
                x = x+h;
            }

            for(int i=0;i<m;i++)   //GTB = G'B
            {   gtb[i]=0;
                for(int j=0;j<n;j++)
                {
                    gtb[i] = g[j][i]*b[j] +gtb[i];
                }   
            }

           a = gausselimination(*c ,gtb,m ); //SOlving for coefficients a
            for(int i=0;i<m;i++)
            {
                mean[i] = mean[i] + a[i];
                var[i] = var[i] + a[i]*a[i];
            }
        }
            for(int i=0;i<m;i++)
            cout<<setw(15)<<"a["<<i+1<<"]"<<setw(20)<<mean[i]/100.0<<setw(20)<<var[i]/100.0 - mean[i]*mean[i]/10000.0<<endl;   
            cout<<endl;
    }
}





