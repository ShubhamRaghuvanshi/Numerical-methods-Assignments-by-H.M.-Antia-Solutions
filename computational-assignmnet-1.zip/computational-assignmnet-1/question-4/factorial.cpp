#include<iostream>
#include<math.h>

int factorial(int n)
{
	int a=1;
	for (int i=1;i<=n;i++)
	{
		a = a*i;
	}
	
return a;
}
