#include<iostream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"

using namespace std;

int main()
{
	
	cout.precision(8);
	int ptr,nop=8;
	float h[nop],x=0,err1[nop],err2[nop],fx,phi[nop],factor=2,phi2[nop];
	h[0]=1;

	for(int i=1;i<nop;i++)
		{		
			h[i] = h[i-1]/factor;

		}
			
	fx = exp(x);

	for(int n=3;n<=3;n=n+2)
	{		
		float f[n-1];
		
		for(int i=0;i<nop;i++)
		{
			for(int j=0;j<(n-1)/2;j++)
			{
				
					f[j +(n-1)/2 ] = exp(x +(j+1)*h[i] );
					f[(n-3)/2-j]   = exp(x - (j+1)*h[i]);					
			}	

		phi[i] 	=first_derivative(f,h[i],n);
		phi2[i] = second_derivative(f,fx,h[i],n);		
		err1[i]= abs(1-phi[i]);
		err2[i] =abs(1-second_derivative(f,fx,h[i],n));

		}
				
		ptr = sort(err1,nop);

		cout<<"*********************************************"<<endl;
			cout<<"OPTIMUM h FOR EXP(x) FOR "<<n<<" POINT CNETRAL DIFFERENCE FOR FIRST DERIVATIVE = "<<h[ptr]<<endl;
	
		for(int j=0;j<(n-1)/2;j++)
			{
				f[j +(n-1)/2 ] = exp(x +(j+1)*h[ptr] );
				f[(n-3)/2-j]   = exp(x - (j+1)*h[ptr]);					
			}

		cout<<"THE CORRESPODING VALUE FOR FIRST DERIVATIVE FOR THE ABOVE h AT x = "<<x<<" IS "<<phi[ptr]<<endl;
		cout<<"*********************************************"<<endl<<endl; 
		
		ptr = sort(err2,nop);
		cout<<"*********************************************"<<endl;
			cout<<"OPTIMUM h FOR EXP(x) FOR "<<n<<" POINT CNETRAL DIFFERENCE FOR SECOND DERIVATIVE = "<<h[ptr]<<endl;
	
			for(int j=0;j<(n-1)/2;j++)
			{
				f[j +(n-1)/2 ] = exp(x +(j+1)*h[ptr] );
				f[(n-3)/2-j]   = exp(x - (j+1)*h[ptr]);					
			}

		cout<<"THE CORRESPODING VALUE FOR SECOND DERIVATIVE FOR THE ABOVE h AT x = "<<x<<" IS "<<second_derivative(f,fx,h[ptr],n)<<endl;
		cout<<"*********************************************"<<endl<<endl; 
	}

cout<<"************************************"<<endl;		
cout<<"BY EXTRAPOLATION FOR FIRST DERIVATIVE"<<endl;
	richardson(phi,nop,factor,2,1,h);
cout<<endl;
cout<<"BY EXTRAPOLATION OF SECOND DERIVATIVE"<<endl;
		richardson(phi2,nop,factor,2,1,h);
cout<<"********************************"<<endl;
return 0;
}	
	


