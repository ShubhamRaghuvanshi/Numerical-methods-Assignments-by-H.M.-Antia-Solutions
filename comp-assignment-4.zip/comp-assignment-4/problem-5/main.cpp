#include<iomanip>
#include<iostream>
#include<math.h>
#include"functions.cpp"
using namespace std;

int main()
{
    cout.precision(12);
    int nop= 1000000;
    double a=0,b=1,I,M,var1,var2;
  
    cout<<"EXACT VALUE OF THE INTEGRAL : "<<exp(1)-1<<endl<<endl;
          
    cout<<"**********  WITHOUT SUBSTRACTING G[X] ****************"<<endl<<endl;

        I = monte_carlo_integration(a,b,nop,func1,0);
        cout<<"INTEGRATION : "<<I<<"        WITH NUMBER OF POINT : "<<nop<<endl;
        var1 = monte_carlo_integration(a,b,nop,func3,0) - I*I;

        cout<<"VARIANCE :       "<< var1<<endl;     
        cout<<"ESTIMATED ERROR: "<<var1/sqrt(nop)<<endl<<endl;

    cout<<endl<<"**********  WITH SUBSTRACTING G[X] = 1+x ************** "<<endl<<endl;
      
        I = monte_carlo_integration(a,b,nop,func2,0);
        cout<<"INTEGRATION : "<<1.5+ I  <<"        WITH NUMBER OF POINT : "<<nop<<endl;
        var2 = monte_carlo_integration(a,b,nop,func4,0) -I*I; 
        cout<<"ESTIMATED ERROR: "<<var2/sqrt(nop)<<endl;        

        cout<<"VARIANCE : "<< monte_carlo_integration(a,b,nop,func4,0) -I*I   <<endl<<endl;
        cout<<"EFFICIENCY : "<<var2/var1<<endl<<endl;

        cout<<"WITH PROBABILOTY DIRTRIBUTION FUNCTION  (1+X)2/3"<<endl;
        I = monte_carlo_integration(a,b,nop,func5,1);
        cout<<"INTEGRATION : "<<I<<"        WITH NUMBER OF POINT : "<<nop<<endl;
        var2 = monte_carlo_integration(a,b,nop,func6,1) - I*I;
        cout<<"VARIANCE :    "<<var2<<endl; 
        cout<<"ESTIMATED ERROR: "<<var2/sqrt(nop)<<endl;  

  return 0;
}
