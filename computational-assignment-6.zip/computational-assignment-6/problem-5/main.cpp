#include<iostream>
#include<iomanip>
#include"functions.cpp"
using namespace std;

int main()
{
    double l=0, y0=1 ;

    cout<<"PART I"<<endl;
  rungekutta(func,sol, l , 1,0,10,32,1,1);

    cout<<"PART II [y0=1]"<<endl;
    rungekutta(func,sol, l , 1,0,10,1024,2,2);

    cout<<"PART II [y0=-1]"<<endl;
    rungekutta(func,sol,l,-1,0,10,1024,2,3);

    cout<<"PART III "<<endl;
    rungekutta(func,sol,l,0,10,0,1024,2,3);

    cout<<"PART IV [l=3]"<<endl;
    rungekutta(func,sol,3,0,0,20,1024,3,4);

    cout<<"PART IV [l=-3]"<<endl;
    rungekutta(func,sol,-3,0,0,20,1024,3,4);

    cout<<"PART IV [l=-20]"<<endl;
    rungekutta(func,sol,-20,0,0,20,1024,3,4);
    
    cout<<"PART IV [l=-100]"<<endl;
    rungekutta(func,sol,-100,0,0,20,1024,3,4);

    cout<<"PART IV [l=-1e-5]"<<endl;
    rungekutta(func,sol,3,-1e5,0,20,1024,3,4);

    cout<<"PART V [n=0]"<<endl;
    rungekutta2(func2,1e-10,10,1024,1,0,0,1,5);
    
    cout<<"PART V [n=1]"<<endl;
    rungekutta2(func2,1e-3,10,1024,0.0005,0.5,1,1,5);

    cout<<"PART VI [l=3]"<<endl;
    rungekutta2(func2,1-1e-15,-1+1e-15,1024,1,6,3,2,6);

    cout<<"PART VI [l=6]"<<endl;
    rungekutta2(func2,1-1e-15,-1+1e-15,4096,1,21,6,2,7);

    cout<<"PART VI [l=7]"<<endl;
    rungekutta2(func2,1-1e-15,-1+1e-15,4096,1,28,7,2,8);


 return 0;
}

//void rungekutta( double(f(double,double,double,int)), double(sol(double, double , int))  ,double l, double y0 ,double t0 , double t1, double nop ,int ques,int ans)


//void rungekutta2( double (f(double,double,double,double,int)) ,double t0, double t1, int nop, double y0, double v0, double n,int qu,int ans)






