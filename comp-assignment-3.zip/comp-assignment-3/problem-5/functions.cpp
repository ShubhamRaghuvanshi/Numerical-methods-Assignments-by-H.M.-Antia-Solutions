#include<iostream>
using namespace std;


float first_derivative(float *fx, float h,int nop)
{


	if(nop==3)
		return ((fx[1]-fx[0])/(2*h));
	else if (nop==5)
		return ((fx[0]-8*fx[1]+8*fx[2]-fx[3])/(12*h));			
	else 
		{
			cout<<"THIS FUNCTION IS ONLY FOR 3 OR 5 POINTS"<<endl;
			return 123;
		}
}

float second_derivative(float *fx,float f, float h,int nop)
{


	if(nop==3)
		return ((fx[0]-2*f+fx[1])/(h*h));
	else if (nop==5)
		return ((-fx[0]+16*fx[1]-30*f+16*fx[2] -fx[3])/(12*h*h));			
	else 
		{
			cout<<"THIS FUNCTION IS ONLY FOR 3 OR 5 POINTS"<<endl;
			return 123;
		}
}

int sort(float *err ,int size_of_e)
{
	float temp;
	int index[size_of_e] ;
	
	
	for(int i=0;i<size_of_e;i++)
		index[i]=i;
		

	for(int i=0;i<size_of_e;i++)
		for(int j=i;j<size_of_e;j++)
			if(err[i]>err[j])	
				{
					temp=err[j];
					err[j]=err[i];
					err[i]=temp;
					
					temp=index[j];
					index[j]=index[i];
					index[i]=temp;
				}	
	return index[0];
}

void richardson(float *phi , int nop,float rho ,float gamma,float exact , float *h)
{
	int col=nop/2;
	float T[nop][col];

	for(int i=0;i<nop;i++)
		T[i][0] = phi[i];

	for(int m=1;m<col;m++)
		for(int i=m;i<nop;i++)
				T[i][m] = T[i][m-1] + (T[i][m-1]- T[i-1][m-1])/(pow(rho,m*gamma)-1);
			
		
	float arr[col-1];
	
	for(int i=0;i<col-1;i++)
		{
		arr[i] = abs(exact-T[i+1][i+1]);	
		}
	col = sort(arr,col-1);
	
cout<<"OPTIMUM VALUE"<<"	"<<T[col+1][col+1]<<endl;	
cout<<"OPTIMUM h ="<<"	"<<h[col+1]<<endl;
	
}



























