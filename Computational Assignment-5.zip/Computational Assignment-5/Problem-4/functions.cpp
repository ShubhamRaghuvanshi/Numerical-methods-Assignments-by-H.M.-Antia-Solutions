
#include<iostream>
#include<math.h>
#include<complex.h>

using namespace std;

double funca1(double x , double n)
{
    return (   log(x/sin(x)) - x/tan(x)   );
} 

double funca2( double x , double n)
{
    double y = x*exp(-x);
    return ( acos(y) +2*n*M_PI - exp(x)*sin(acos(y))   );
}



double realfunc2(double x,double n){
  double f;
  f = 1.0;
  for(int i=1;i<=n;i++){
    f = f*(x - 1.0*i);
  }
  f = f + pow(2,-10)*pow(x,14);
  return f;
}


complex<double> func(complex<double> x){
  complex<double> f;
  f = {1.0, 0.0};
  for(int i=1;i<=20;i++){
    f = f*(x - (1.0*i+(1.0,0.0)));
  }
  f = f + pow(2,-10)*pow(x,14);
  return f;
}


complex<double> dfunc(complex<double> x){
  return -8.7529480367616e18 + 2.76075195072814e19*x - 
    3.86127937354530e19 *pow(x,2) + 3.21512472905802e19 *pow(x,3) - 
    1.79998975897380e19 *pow(x,4) + 7.2398868226822e18 *pow(x,5) - 
    2.17933550212973e18 *pow(x,6) + 5.04246496794359e17 *pow(x,7) - 
    9.1280698789603e16 *pow(x,8) + 1.30753501054040e16 *pow(x,9) - 
    1.49143701189483e15 *pow(x,10) + 1.35723323944572e14 *pow(x,11) - 
    9.82944539850000e12 *pow(x,12) + 5.62404802820014e11 *pow(x,13) - 
    2.50842123000000e10 *pow(x,14) + 8.53247136000000e8 *pow(x,15) - 
    2.136645000000000e7 *pow(x,16) + 371070.0000000000 *pow(x,17) - 
    3990.000000000000 *pow(x,18) + 20.00 *pow(x,19);
}

complex<double> ddfunc(complex<double> x){
  return 2.76075195072814e19 - 7.7225587470906e19*x + 
    9.6453741871741e19 *pow(x,2) - 7.1999590358952e19 *pow(x,3) + 
    3.61994341134112e19 *pow(x,4) - 1.30760130127784e19 *pow(x,5) + 
    3.52972547756051e18 *pow(x,6) - 7.30245590316824e17 *pow(x,7) + 
    1.17678150948636e17 *pow(x,8) - 1.49143701189483e16 *pow(x,9) + 
    1.49295656339029e15 *pow(x,10) - 1.179533447820000e14 *pow(x,11) + 
    7.31126243666018e12 *pow(x,12) - 3.51178972200000e11 *pow(x,13) + 
    1.279870704000000e10 *pow(x,14) - 3.41863200000000e8 *pow(x,15) + 
    6.30819000000000e6 *pow(x,16) - 71820.0000000000 *pow(x,17) + 
    380.0000000000000 *pow(x,18);
}


double bisect(double (*func)(double,double),double x1,double x2,int n,int niter,double aeps)
{
    int i;     
    double f1,f2,f3;
    for (i=0;i<niter;i++)
    {
        f1 = func(x1,n);
        f2 = func(x2,n);
        f3 = func((x1+x2)/2,n);

        if(abs(x1-x2)<aeps)
            break;

        if(f1*f3>0)
            x1 = (x1+x2)/2;
        if(f2*f3>0)
            x2 = (x1+x2)/2;
     }   
    return x1;
}



double bisection( double (*func)(double,double ),double a,double b,int n,int nop,double aeps,int question)
{
    cout.precision(10);
    double h=(b-a)/nop,x1=a,x2=a+h,x,fx;
    int root=1;

    for(int i=0;i<nop;i++)
    {   
        x1 = x1+h;
        x2 = x1+h; 
        if(func(x1,n)*func(x2,n)>0)
            continue;
        else
        {
            x = bisect(func,x1,x2,n,1000,aeps);
            fx = func(x,n);
     //       cout<<"     "<<x<<"     "<<fx<<"    "<<realfunc2(x,n)<<"    "<<realfunc2(1,n)<<endl;
            if(question==1||question==2)
             {
               if(abs(fx)<1e-3)
                { 
                    if(question==1)        
                        cout<<setw(5)<<"ROOT "<<root<<" = {"<<log(x/sin(x))<<" , "<<x<<"}"<<endl; 
                    if(question==2)
                        cout<<setw(5)<<"ROOT "<<root<<" = {"<<x<<" , "<<acos(x*exp(-x))+2*n*M_PI<<"}"<<endl;                     
                root = root+1;         
                }            
              }  
                if(question==3)
                {
                    cout<<"ROOt "<<root<<" = "<<x<<endl;
                    root = root+1;    
                }
                                             
         }
  }
}


complex<double> laguerre(complex<double> x, int n,complex<double>(*func)(complex<double>), complex<double>(*dfunc)(complex<double>),complex<double>(*ddfunc)(complex<double>),int niter,double aeps  )
{  
  complex<double> df, H, r1, r2, tempx= (1000.0, 1000.0);

  for(int i=0;i<niter;i++)
    {
        df = dfunc(x);
        H =  (1.0*n -1.0)*((1.0*n - 1.0)*df*df - (1.0*n)*func(x)*ddfunc(x));
        r1 = df + sqrt(H);
        r2 = df - sqrt(H);
        if(abs(r1)>abs(r2)){
          x = x - (1.0*n)*func(x)/r1;
        }
        else{
          x = x - (1.0*n)*func(x)/r2;
        }
        if(abs(x-tempx)<aeps){
          return x;
        }
        tempx = x;
     }
  return x;
}






