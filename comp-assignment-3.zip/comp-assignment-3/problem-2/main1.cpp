#include<iostream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"

using namespace std;

int main()
{
	
	cout.precision(8);
	
	double x[10];
	for(int i=0;i<10;i++)
	x[i] = 1.560 + 0.001*(i+1);
	
	

	

	for(int nop=2;nop<=10;nop= nop+2)
	{

	double Tan[nop],Sin[nop],Cos[nop],SIN[7],COS[7],*y ,*df;
	double point[] ={1.5715,1.5705, 1.5695,1.5634,1.5614,1.5605,1.5585};

	
   	cout<<"******************FOR n="<<nop<<endl<<endl;
	cout<<"*********	INTERPOLATION OF SIN(X)	*******"<<endl;
	cout<<"ESTIMATED VALUES 	ACTUAL VALUES		POINT OF ESTIMATION"<<endl;


	for(int i=0;i<7;i++)
	{
		y = nearest_n_points(x,point[i],nop,10);
		for(int j=0;j<nop;j++)
			Sin[j] = sin(y[j]);
		df = difftable(Sin,y,nop);	
		SIN[i] = interpolate(nop,df,Sin[0],point[i],y);	
		cout<<setw(15)<<SIN[i]<<setw(20)<<sin(point[i])<<setw(25)<<point[i]<<endl;
	}cout<<endl<<endl; 

	cout<<"*********	INTERPOLATION OF COS(X)	*******"<<endl;
	cout<<"ESTIMATED VALUES 	ACTUAL VALUES		POINT OF ESTIMATION"<<endl;

	for(int i=0;i<7;i++)
	{
		y = nearest_n_points(x,point[i],nop,10);
		for(int j=0;j<nop;j++)
			Cos[j] = cos(y[j]);
		
		df = difftable(Cos,y,nop);	
		COS[i] = interpolate(nop,df,Cos[0],point[i],y);			
		cout<<setw(15)<<COS[i]<<setw(20)<<cos(point[i])<<setw(25)<<point[i]<<endl;
	}cout<<endl<<endl; 

	cout<<"*********	INTERPOLATION OF TAN(X)	*******"<<endl;
	cout<<"ESTIMATED VALUES 	ACTUAL VALUES		SIN[X]/COS[X]	      POINT OF ESTIMATION"<<endl;

	for(int i=0;i<7;i++)
	{
		y = nearest_n_points(x,point[i],nop,10);
		for(int j=0;j<nop;j++)
			Tan[j] = tan(y[j]);
		df = difftable(Tan,y,nop);	
		cout<<setw(15)<<interpolate(nop,df,Tan[0],point[i],y)<<setw(20)<<tan(point[i])<<setw(25)<<SIN[i]/COS[i]<<setw(25)<<point[i]<<endl;
	}cout<<endl<<endl;

	} 

return 0;
}
