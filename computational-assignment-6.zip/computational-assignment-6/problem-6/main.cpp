#include<iostream>
#include<iomanip>
#include<fstream>
#include"functions.cpp"
using namespace std;

int main()
{
    int nop=128;
    double y[nop],tf=1,ti=0,h =(tf-ti)/double(nop);

    ofstream data1,data2,data3,data4;

     data1.open("data1.txt");    
     data2.open("data2.txt");
     data3.open("data3.txt");
     data4.open("data4.txt");

     cout<<"PART I"<<endl;     
     boundary (func , ti, tf, nop, 1,1,0,1,y); 
        
        for(int i=0;i<nop;i++)  
        {     
             ti = i*h;   
             data1<<y[i]<<"  "<<ti<<endl;
        }
     cout<<"PART II (l=3)"<<endl;  
     ti =-1+1e-14 ; tf =1-1e-14 ; 
     h =(tf-ti)/double(nop) ;
     boundary (func , -1+1e-14, 1-1e-14, nop, -1,1,3,2,y); 
     
        for(int i=0;i<nop;i++)  
        {     
             ti = i*h;   
             data2<<y[i]<<"  "<<ti<<endl;
        }   


     cout<<"PART II (l=6)"<<endl;     
     ti =-1+1e-14 ; tf =1-1e-14 ;  
     boundary (func , -1+1e-14, 1-1e-14, nop, 1,1,6,2,y); 
       for(int i=0;i<nop;i++)  
        {     
             ti = i*h;   
             data3<<y[i]<<"  "<<ti<<endl;
        }   


     cout<<"PART II (l=7)"<<endl;     
         ti =-1+1e-14 ; tf =1-1e-14 ;  

     boundary (func , -1+1e-14, 1-1e-14, nop, -1,1,3,2,y); 
           for(int i=0;i<nop;i++)  
        {     
             ti = i*h;   
             data4<<y[i]<<"  "<<ti<<endl;
        }   




    return 0;
}

//void boundary( double (f(double,double,double,double,int)) ,double t0 , double t1 , int nop , double yi,double yf,double n , int qu ) 
