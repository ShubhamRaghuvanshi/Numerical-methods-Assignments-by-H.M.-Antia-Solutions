#include<iostream>
#include<iomanip>
#include<complex.h>
#include"functions.cpp"

using namespace std;

int main()
{
    cout<<endl<<"PART A"<<endl;
    cout<<"ELIMINATING X AND SOLVING FOR Y : "<<endl;
    bisection( funca1,-10,10, 0,16,1e-10,1);    
    cout<<endl<<"ELIMINATING Y AND SOLVING FOR X : "<<endl;
    for(int n=0;n<2;n++)
    {
        cout<<"THE ROOT FOR n = "<<n<<"   ";
        bisection( funca2,-10,10, n,16,1e-10,2);
    }
    cout<<"***************************************************************************"<<endl;

    cout<<"PART B"<<endl;
    complex<double> x0 ,root ;
    double temp=1000,imtemp=1000;
    x0 = {1,1};
    for(int i=0;i<20;i++)
    {
        root = laguerre(x0,20,func,dfunc,ddfunc,50,1e-10); 
        if(abs(root.imag())<1e-10)
        {
            if(root.real()!=temp)
                cout<<"REAL ROOT = "<<root.real()<<endl;
            temp = root.real();
        }
         else
            {   
               if(!(abs(root.imag()-imtemp)<1e-10))
                { 
                    cout<<"COMPLEX ROOT = "<<root<<endl;
                    x0 = {x0.real(), -x0.imag()};
                    root = laguerre(x0,20,func,dfunc,ddfunc,50,1e-10); 
                    cout<<"COMPLEX ROOT = "<<root<<endl;
                }
                imtemp = root.imag();
            }   
       x0 = {x0.real()+1,x0.imag()};         
    } 
        cout<<"***************************************************************************"<<endl;
    return 0;
}
