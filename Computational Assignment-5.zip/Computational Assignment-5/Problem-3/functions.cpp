#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;

double func1(double y,double a){
  return sin(4.0/(tan(y)*tan(y)+y*y+a));
}

double func21(double x, double y){
 return ((sin(x*y+(M_PI/6.0))+sqrt(x*x*y*y+1.0))/(cos(x-y)))+2.8;
}

double func22(double x,double y){
 return (x*exp(x*y+M_PI/6) - sin(x-y))/sqrt(x*x*y*y+1)-1.66;
}

double dxfunc21(double x,double y){
    double temp1 =sqrt(1+x*x*y*y) ;
    double temp2 =x*y +M_PI/6 ;  
  return (x*y*y/temp1 +y*cos(temp2) + (temp1 +sin(temp2))*tan(x-y) )/cos(x-y);
}

double dyfunc21(double x,double y){
    double temp1 =sqrt(1+x*x*y*y) ;
    double temp2 =x*y +M_PI/6 ;  
   return ( x*x*y/temp1 +x*cos(temp2) - ( temp1+sin(temp2))*tan(x-y)  )/cos(x-y);
}

double dxfunc22(double x,double y){
    double temp = 1+x*x*y*y;
    double temp1 = 1+x*y,temp2=x*y;
    return ( (exp(x*y +M_PI/6)*(temp + temp2*temp2*temp2) - temp*cos(x-y) + temp2*y*sin(x-y))/pow(temp,1.5) );
}

double dyfunc22(double x,double y){
     double temp = 1+x*x*y*y;
      double temp1 = x*y;
    return (temp*cos(x-y) + x*x*(  exp(x*y +M_PI/6)*(1-temp1+temp1*temp1)+y*sin(x-y) )) /pow(temp,1.5);
}



double bisect(double (*func)(double,double),double x1,double x2,double n,int niter,double aeps)
{
    int i;     
    double f1,f2,f3;
    for (i=0;i<niter;i++)
    {
        f1 = func(x1,n);
        f2 = func(x2,n);
        f3 = func((x1+x2)/2,n);

        if(abs(x1-x2)<aeps)
            break;

        if(f1*f3>0)
            x1 = (x1+x2)/2;
        if(f2*f3>0)
            x2 = (x1+x2)/2;
     }   
    return x1;
}



int bisection( double (*func)(double,double),double a,double b,double n,int nop,double aeps ,double *sol)
{
    cout.precision(10);
    double h=(b-a)/nop,x1=a,x2=a+h,x,fx;
    int rootcount=0;

    for(int i=0;i<nop;i++)
    {   
        x1 = x1+h;
        x2 = x1+h; 
        if(func(x1,n)*func(x2,n)>0)
            continue;
        else
        {
            x = bisect(func,x1,x2,n,1000,aeps);
            fx = func(x,n);
                if(abs(fx)<1e-4)
                {
                    sol[rootcount] = x;                 
                    rootcount = rootcount+1;         
            }            
        }
  }
    return rootcount;
}

void newton( double (*func1)(double,double) ,double (*func2)(double,double) , double (*dxfunc1)(double,double) ,double (*dyfunc1)(double,double) ,double (*dxfunc2)(double,double),double (*dyfunc2)(double,double),double *x ,int niter ,int step) 
{
    double J[2][2],dx[2],det,f0,f1;
    int i;

    for(i=0;i<niter;i++)
    {
        J[0][0] = dxfunc1(x[0],x[1]);   J[0][1] = dyfunc1(x[0],x[1]); 
        J[1][0] = dxfunc2(x[0],x[1]);   J[1][1] = dyfunc2(x[0],x[1]);  
        f0 =func1(x[0],x[1]);           f1 =func2(x[0],x[1]); 
 // cout<<setw(20)<<x[0]<<setw(20)<<x[1]<<setw(20)<<f0<<setw(20)<<f1<<setw(20)<<J[0][0]<<endl;    
 //   cout<<J[0][0]<<setw(20)<<J[0][1]<<setw(20)<<J[1][0]<<setw(20)<<J[1][1]<<endl;

        if((abs(f0)<1e-10)&&(abs(f1)<1e-10)) break;  
        det = J[0][0]*J[1][1] - J[0][1]*J[1][0];  
        dx[0] =  (f1*J[0][1] -f0*J[1][1] )/det;
        dx[1] =  (f0*J[1][0] -f1*J[0][0] )/det;   
        x[0] = x[0] + dx[0]/step;
        x[1] = x[1] + dx[1]/step;
 
    }
    if(i!=niter)
    cout<<"RESULT ACHIEVED IN "<<i<<" STEPS  ";
    else cout<<"DIDNT CONVERGER TO ROOT :"<<endl;
}




