#include<iostream>
#include<iomanip>
#include"basen.h"
#include<math.h>


using namespace std;
#define printx for(int s=0;s<4;s++)cout<<x[s]

	
int main()
{
	cout.precision(20);
	long double a[31][31],f=0,x;
	int m=31,count=0,sign[2];
	//a[i][j] denotes the coeficient of i'th power of x in the polynomial of order j

	
	for(int i=0;i<31;i++)
		a[i][i]=1;				//The coeficient of biggest power is 1
			
	for(int i=1;i<31;i++)	
		a[0][i]=-i*a[0][i-1];	//Last coeficient is product of all roots *(-j)
		
	for(int k=2;k<31;k++)
	{	
		for(int i=1;i<k;i++)
		{
			a[i][k] = a[i-1][k-1]-k*a[i][k-1];	//Recursion relation	
		}
	}

	cout<<"**COEFICIENTS OF THE POLYNOMIAL(IN THE INCREASING POWERS OF X) ARE :"<<endl<<endl;	
	for(int i=0;i<31;i++)
	{
			cout<<a[i][m-1]<<setw(20)<<" x^"<<i<< "	"<<endl;
			
	}
	cout<<"******************************************"<<endl;	

	for(int k=0;k<320;k++)
	{	
		x = -0.05+0.1*k;
		f=0;
		for(int i=0;i<m;i++)
		{
			f = a[i][m-1]*pow(x,i)+f;
		}
	
		if(f>0)
			sign[k%2]=1;
		else
			sign[k%2]=-1;
		if(k!=0)
		{
			if(sign[k%2]!=sign[(k+1)%2])
			count++;						//count is number of sign changes
		}

	}
	cout<<"NUMBER OF SIGN CHANGES OBSERVED =	"<<count<<endl;		
	

return 0;
}


