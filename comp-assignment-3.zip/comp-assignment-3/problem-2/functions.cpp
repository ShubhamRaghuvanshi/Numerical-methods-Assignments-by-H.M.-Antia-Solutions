
#include<iostream>

using namespace std;

double *difftable(double *fx, double *x,int nop)
{	
	double *df;
	df = new double[(nop)*(nop-1)];
	
	for(int i=0;i<nop;i++)
		for(int j=0;j<nop-i-1;j++)
			if(i==0)
				df[j*(nop-1)+i] = (fx[j+1]-fx[j])/(x[j+1]-x[j]);
			else
				df[j*(nop-1)+i] = (df[(j+1)*(nop-1)+i-1] -df[j*(nop-1)+i-1])/(x[j+1+i]-x[j]); 
	
	return df;
}

double interpolate(int nop , double *df, double fx0,double p ,double *x)
{
	double fox = fx0,product=1;
	
	for(int i=0;i<nop-1;i++)
	{
		product = product*(p - x[i]);		
		fox = fox + product*df[0*(nop-1)+ i];
	}
	return fox;

} 

double *nearest_n_points(double *x , double point , int n,int size_of_x)
{
	double  *points,diff[size_of_x],temp;
	int index[size_of_x] ;
	points= new double[n];
	
	for(int i=0;i<size_of_x;i++)
		{
			diff[i] = abs(x[i]-point);
			index[i]=i;
		}

	for(int i=0;i<size_of_x;i++)
		for(int j=i;j<size_of_x;j++)
			if(diff[i]>diff[j])	
				{
					temp=diff[j];
					diff[j]=diff[i];
					diff[i]=temp;
					
					temp=index[j];
					index[j]=index[i];
					index[i]=temp;
				}	

	for(int i=0;i<n;i++)
		points[i] = x[index[i]];	
	
	return points;
}




























