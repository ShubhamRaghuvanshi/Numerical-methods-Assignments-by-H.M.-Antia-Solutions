#include<iostream>
#include<iomanip>
#include<math.h>
#include "function.cpp"
using namespace std;
int main()
{
    int n=50,m=3;
  
    cout<<setw(26)<<"DELSQ"<<setw(21)<<"CHISQ"<<endl<<endl;
    for(m=3;m<=10;m++) 
    {
        cout<<"m = "<<m-1<<"  ";
        chisq(func,n,m,1,1);
    } 
    cout<<endl;
    
    cout<<"FOR 6TH ORDER POLYNOMIAL"<<endl;
    cout<<setw(20)<<"COEFFICIENT"<<setw(15)<<"MEAN"<<setw(20)<<"VARIANCE"<<endl<<endl;    
    chisq(func,n,7,1,2);

    cout<<"############################################################"<<endl;
    cout<<"FOR SECOND FUNCTION"<<endl;

    cout<<setw(26)<<"DELSQ"<<setw(21)<<"CHISQ"<<endl<<endl;
    for(m=3;m<=10;m++) 
    {
        cout<<"m = "<<m-1<<"  ";
        chisq(func,n,m,2,1);
    } 
    cout<<endl;
    
    cout<<"FOR 6TH ORDER POLYNOMIAL"<<endl;
    cout<<setw(20)<<"COEFFICIENT"<<setw(15)<<"MEAN"<<setw(20)<<"VARIANCE"<<endl<<endl;    
    chisq(func,n,7,2,2);
    cout<<"#############################################################"<<endl;

    cout<<"USING L1-APPROXIMATION"<<endl;

     m=7;
for(int q=1;q<=2;q++)
{
    cout<<"FOR FUNCTION "<<q<<endl;
        cout<<setw(20)<<"COEFFICIENT"<<setw(15)<<"MEAN"<<setw(20)<<"VARIANCE"<<endl<<endl; 
    double mean[m]={0} ,var[m] = {0};   
    for(int l=0;l<100;l++)
    {  
        n=50;
        double chi1;
        double *x = new double [n];
        double *coeff,sigma[n],f[n];

        for(int i=0;i<n;i++)
        {
            x[i] = 1.0*i/(n-1);
            f[i] = func(x[i],q);
        }
   
      coeff = thecoefficientsl1(x,f,sigma,n,m,chi1);

      for(int i=0;i<m;i++)
      {
           mean[i] = mean[i] + coeff[i];
           var [i] = var[i] + coeff[i]*coeff[i];    
      }   

            
 
 // del[l] = delsq(coeff,x,m,n);
  delete[] x;
  delete [] coeff;
 }
     for(int i=0;i<m;i++)  
        cout<<setw(15)<<"a["<<i+1<<"]"<<setw(20)<<mean[i]/100.0<<setw(20)<<var[i]/100.0 - mean[i]*mean[i]/10000.0<<endl;
        cout<<endl;
}
    return 0;
}
