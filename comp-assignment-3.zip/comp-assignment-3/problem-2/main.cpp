#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"

using namespace std;

int main()
{
	
	cout.precision(8);	
	int nop=10;

	double x[nop],Sin[nop] ,*df;
	double point[] ={1.5716,1.5736,1.5634,1.5604,1.5584};


	for(int i=0;i<nop;i++)
	{
		x[i] = 1.560 + 0.001*(i+1);
		Sin[i] = sin(x[i]);
	}

	cout<<"*********	INTERPOLATION OF SIN(X)	*******"<<endl<<endl;
	cout<<"    ESTIMATED VALUES 	      ACTUAL VALUES		POINT OF ESTIMATION"<<endl;

	df= difftable(Sin,x,nop);
	for(int i=0;i<5;i++)
	{
		cout<<setw(15)<<interpolate(nop,df,Sin[0],point[i],x)<<setw(25)<<sin(point[i])<<setw(25)<<point[i]<<endl;
	}cout<<endl<<endl;

	
//	inverse interpolation
	cout<<"********	INVERSE INTERPOLATION IF SIN(X)********"<<endl<<endl;
	double sinosoid[] = {0.999995,0.99995,0.9999,0.9995};

	cout<<"     ESTIMATED VALUES     	ACTUAL VALUES		POINT OF ESTIMATION"<<endl;
	df= difftable(x,Sin,nop);
	for(int i=0;i<4;i++)
	{
		cout<<setw(15)<<interpolate(nop,df,x[0],sinosoid[i],Sin)<<setw(28)<<asin(sinosoid[i])<<setw(25)<<sinosoid[i]<<endl;
	}cout<<endl<<endl;


//inverse interpolation	

	for(int i=0;i<nop;i++)
	{
		x[i] = 1.564 + 0.001*(i+1);
		Sin[i] = sin(x[i]);
	}

	cout<<"*********	INTERPOLATION USING 1.564+0.001*i	*******"<<endl<<endl;
	cout<<"    ESTIMATED VALUES 	     ACTUAL VALUES		POINT OF ESTIMATION"<<endl;
	
	df= difftable(Sin,x,nop);

	for(int i=0;i<5;i++)
	{
	
		cout<<setw(15)<<interpolate(nop,df,Sin[0],point[i],x)<<setw(25)<<sin(point[i])<<setw(25)<<point[i]<<endl;
	}cout<<endl<<endl;



return 0;
}
