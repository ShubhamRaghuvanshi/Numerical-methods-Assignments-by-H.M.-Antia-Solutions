#include<iostream>
#include<math.h>
#include<iomanip>

using namespace std;

    double func1(double x)
    {
        return (exp(-5*x*x)*cos(10*x*x));       
    }

    double func21(double x)
    {
        return (1/(x-sin(x)));     
    }

     double func22(double x)
    {
        return ( 5040/(840*x*x*x  - 42*x*x*x*x*x + x*x*x*x*x*x*x) );    
    }

    double func23(double x, double a)
    {
        return (a/(x-sin(x)));    
    }

    double func3(double x,double b)
    {
        return (2/sqrt ( ((b+3)+(b-1)*x)*((3*b+1) +(b-1)*x)  ) );        
    }
    
    double func4(double x)
    {
        return ( exp( pow(x,100)));      
    }
    
    double func5(double x)
    {
        return (1/(1-exp(-x))-1/x);
    }

   double func61(double x)
    {
          return (  exp(x)/((1+4*exp(2*x))*pow((x+log(2)), 2)) );
    }

    double func62(double x)
    {
          return (  exp(x)/((1+4*exp(2*x))*pow((x+log(2)), 1.5)) );
    }
    
    double func63(double x)
    {
          return (  exp(x)/((1+4*exp(2*x))*pow((x+log(2)), 1.1)) );
    }

    double func64(double x)
    {
          return (  exp(x)/((1+4*exp(2*x))*pow((x+log(2)), 1.01)) );
    }

    double func65(double x)
    {
          return (  exp(x)/((1+4*exp(2*x))*pow((x+log(2)), 1.001)) );
    }


    double func7(double x, double t)
    {
        return ( sqrt(log(x))/(x*(x-t)) );     
    }

    double func8(double x,double alpha)
    {
        return (sqrt(x)/(exp(alpha) + exp(-x)));
    }
    

double gauss_legendre(double (*func)(double), double a, double b, int divisions,double *H, double *ab,int nop)
{
  
    double h=(b-a)/divisions;
    double x,sum=0;
    int fe=0;

    for(int i=1;i<=divisions;i++)
    {
        b=a+h;
        for(int j=0;j<nop;j++)
        {
            x = (a+b+(b-a)*(ab[j]))/2;
            sum = sum + H[j]*func(x);
            x = (a+b+(b-a)*(-ab[j]))/2;
            sum = sum + H[j]*func(x);
            fe = fe+2;
        }
        a=b;
    }   
    cout<<endl<<"NUMBER OF FUNCTION EVALUATIONS :"<<fe<<endl;
    return sum*h/2;
}



double gausss_chebeshev(int nop ,double (*func)(double,double)  ,double b)
{
    double sum=0;
    int fe=0;
    
    for(int i=1;i<=nop;i++)
    {
        sum = sum + (M_PI/nop)* func ( cos( (2*i-1)*M_PI/(2*nop) ) , b );         
        fe = fe+1;
    }
    cout<<endl<<"NUMBER OF FUNCTION EVALUATIONS :"<<fe<<endl;
  return sum;  
}   



double gauss_legendre1(double *H, double *ab,double (*func)(double),int min,int max,int &fe)
{
    double sum=0;
    for(int i=min;i<max;i++)
    {
        sum+=H[i]*func(ab[i]);    
        fe = fe+1;
    } 
   return sum;
}


double laguarre(double (*func)(double), double *H , double *ab)
{
    double err,i1,i0=1;
    int min=0,max,i,fe=0;
    int &fec = fe;
    for( i=1;i<=5;i++)
    {
        max=min+pow(2,i);
        i1=gauss_legendre1(H,ab,func,min,max ,fe);
        err=abs((i1-i0)/i1);
 
        if((i>1)&&(err<5e-11))
            break;
        i0=i1;
        min=max; 
    }
    if(i==6)
        cout<<" NOT CORRECT UPTO 12 DECIMAL PLACES "<<endl;
    cout<<endl<<"NUMBER OF FUNCTION EVALUATIONS :"<<fe<<endl;
    return i1;
}

double gauss_legendre1(double *H, double *ab,double (*func)(double, double),int min,int max,int &fe,double alpha)
{
    double sum=0;
    for(int i=min;i<max;i++)
    {
        sum+=H[i]*func(ab[i],alpha);    
        fe = fe+1;
    } 
   return sum;
}



double laguarre(double (*func)(double,double), double *H , double *ab ,double alpha)
{
    double err,i1,i0=1;
    int min=0,max,i,fe=0;
    int &fec = fe;
    for( i=1;i<=5;i++)
    {
        max=min+pow(2,i);
        i1=gauss_legendre1(H,ab,func,min,max ,fe ,alpha);
        err=abs((i1-i0)/i1);
 
        if((i>1)&&(err<5e-11))
            break;
        i0=i1;
        min=max; 
    }
    if(i==6)
        cout<<" NOT CORRECT UPTO 12 DECIMAL PLACES "<<endl;
    cout<<endl<<"NUMBER OF FUNCTION EVALUATIONS :"<<fe<<endl;
    return i1;
}




    


