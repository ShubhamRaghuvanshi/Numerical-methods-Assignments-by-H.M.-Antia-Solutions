#include<math.h>
#include<iostream>
#include<iomanip>
#include"functions.cpp"

using namespace std;

int main()
{
    cout.precision(10);
    int nop=10000000;
    double k[] = {0.1,0.5,1,2}  ,actual;
    
    cout<<"ACTUAL VALUE : "<<M_PI*M_PI/6<<endl<<endl;
    cout<<"CALCULATED INTEGRAL "<<setw(30)<<"NUMBER OF POINTS"<<setw(30)<<"ACTUAL VALUE "<<endl<<endl;

    actual = M_PI*M_PI/6.0;
 
    cout<<"I1"<<endl;
    cout<<setw(5)<<monte_carlo(nop,func1)<<setw(40)<<nop<<setw(27)<<actual<<endl<<endl ;
 
    cout<<"I2"<<endl;
    for(int i=0;i<4;i++)
    {
     actual =sin(k[i]);
     cout<<setw(5)<<monte_carlo(nop,func2,k[i])<<setw(37)<<nop;
     cout<<setw(30)<<actual<<setw(15)<<"K = "<<k[i]<<endl;
    }
return 0;
}
