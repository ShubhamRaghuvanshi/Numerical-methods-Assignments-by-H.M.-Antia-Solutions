#include<iostream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"
using namespace std;


int main()
{
    double aeps=1e-10;

   cout<<"PART A"<<endl;  
   cout<<"******************"<<endl;
    cout<<"alpha = 2:"<<endl;
        bisection(func11,-2,2,200,aeps);
    cout<<"******************"<<endl;
    cout<<"alpha = 10:"<<endl; 
        bisection(func12,-10,10,200,aeps);
    cout<<"******************"<<endl;
    cout<<"alpha = 20:"<<endl; 
        bisection(func13,-20,20,200,aeps);
    cout<<"******************"<<endl;
    cout<<"alpha = 20.3959:"<<endl; 
        bisection(func14,-25,25,5000,aeps);
    
    cout<<"***********************************"<<endl;   
          
    cout<<"PART B"<<endl;
        bisection(func2,0,317,200000,aeps);
    cout<<"***********************************"<<endl; 

    cout<<"PART C"<<endl;
        aeps=1e-300;
        bisection(func3,0,2,1024,aeps);
    cout<<"***********************************"<<endl; 

    cout<<"PART D"<<endl;
        bisection(func4,0,10,200,aeps);
    cout<<"***********************************"<<endl; 


return 0;
}




