#include<iostream>
#include<iomanip>
#include<fstream>
#include"functions.cpp"

using namespace std;

int main()
{
    cout.precision(7); 
    int N=400,i=0,n[]={N,N-2}; 
    double w[N][N] ={0},l,u,temp,guess[N],m;
    double xi=-10 ,xf=10, h = (xf-xi)/double(N-1); 
        
    ofstream data3, data4;
    data3.open("part21.txt");
    data4.open("part22.txt");

    initialize(*w,h,xi,xf,N,2);

 
   // print(*w,N);
    l = w[i][i] -abs( w[i+1][i] );
    u = w[i][i] +abs( w[i+1][i] );
    for( i=1;i<N;i++)
    {     
        if (i==N-1)
            temp = abs( w[i][i-1] ) ;
        else
             temp =abs( w[i][i-1] )+ abs( w[i+1][i] );
        if(l> w[i][i]-temp)
        l=w[i][i]-temp;  
        if(u<w[i][i]+temp)
        {u =w[i][i]+ temp;}

    }


    data3<<0<<" "<<0.0<<endl;
    data4<<0<<" "<<0.0<<endl;
   
for(int i=N-1;i<=N;i++)
{
    xi = h;
    sturm(*w,N,l,u,guess,i,m,1e-15);
    cout<<N-i+1<<" th EIGENVALUE IS :"<<setw(30)<<m<<endl;
    cout<<endl<<"THE CORRESPONDING EIGENVECTOR IS WRITTEN IN THE FILE AND PLOTTED:"<<endl;   
   for(int j=0;j<N;j++)
    {
       if(i==N) data3<<xi<<" "<<guess[j]<<endl;
       if(i==N-1) data4<<xi<<" "<<guess[j]<<endl;
       xi = xi+h; 
    } 
  cout<<endl<<"***************************************************"<<endl;
  
}
       data3<<21<<" "<<0.0<<endl;
       data4<<21<<" "<<0.0<<endl;

    data3.close();
    data4.close();


    return 0;
}
