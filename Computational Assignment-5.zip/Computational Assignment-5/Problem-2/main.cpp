#include <iostream>
#include "lagurw.cpp"
#include"functions.cpp"

using namespace std;
int main()
{
    cout.precision(10); 
    int N=70;
    double a0[N],w[N],n[] = {1e-3,1,1e3};

    cout<<"PART A"<<endl;
    lagurw_list(a0, w, 2, N);
    for(int i = 0; i < 3; i++){
      cout<<"FOR n = "<<n[i]<<"      ";
      bisection(  F, -10, 20, n[i],w,a0,N,2048); }
    cout<<"******************************************************************************"<<endl;

    cout<<"PART B"<<endl;
 
    for(int j=0;j<3;j++)
    {
        double a=1,b=2;
        int noe=0,ier;
 
        if(j==0) N=4;
        if(j==1) N=6;
        if(j==2) N=10;
        cout<<endl<<"FOR N = "<<N<<" THE EIGEN VALUE ARE "<<endl;
        for(int i=0;i<20;i++)
        {      
            ier = bisection(  f2, a,b, n[0],w,a0,N,8*pow(2,i));   
            if(ier==0)
            {
                noe = noe+1;
                ier=1;
            }
            if(noe==N)
            break;
            b=a;
            a = b/10; 
         }   
    }  
    cout<<"******************************************************************************"<<endl;
return 0;
}
