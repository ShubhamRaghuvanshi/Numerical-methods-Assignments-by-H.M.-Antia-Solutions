#include<iostream>
#include<iomanip>

using namespace std;

int main()
{
	cout.precision(10);
	
	double j0,j1,j2;
	j0=0.7651976865;	
	j1=0.4400505857;	
	
	cout<<"j_0[1] = "<<j0<<endl;
	cout<<"j_1[1] = "<<j1<<endl;

	for(int n=1;n<30;n++)
	{
		j2 = 2*n*j1-j0;
		j0=j1;
		j1=j2;
		cout<<"j_"<<n+1<< "[1] = "<< j2<<endl;
	}
	
return 0;
}

