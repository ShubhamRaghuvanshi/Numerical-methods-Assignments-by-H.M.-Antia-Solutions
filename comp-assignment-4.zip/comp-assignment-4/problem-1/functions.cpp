#include<iostream>
#include<math.h>
using namespace std;

    double func1(double x)
    {
        return pow(x,x);
    }

    double func2(double x)
    {
        return (exp(-(x+1/x))/pow(x,20));
    }

    double func3(double x)
    {
        return (log(1/x)*sin(x));    
    }

    double func4(double x)
    {
        return ((2/sqrt(M_PI)*exp(-x*x)));
    }

    double func5(double x)
    {
        return (exp(1/x));
    }

    double func6(double x,double b)
    {
        return (1/(b+ sin(20*M_PI*x)));
    }

    double func7(double x)
    {
        double sum=0,w[2];
        int j;
        for(j=1;j<55;j++)
        {
            w[j%2]=sum;
            sum = sum + pow(2,-j)* cos (pow(7,j)*M_PI*x);
            w[(j+1)%2]=sum;    
      
            if(abs(w[1]-w[0])<1e-13)
             {break;}       
    }        
        if(j==49)
        cout<<"FUNCTION DIDNT CONVERGE "<<endl;
    return (sum/M_PI);

    }    

  

   double simpson_one_third(double a, double b , double (*func)(double),int nop)
    {
        int i=0;
        double even=0,odd=0;
        double h = (b-a)/double(nop-1);
        double x=a, increment=2*h;       
     
        i=0;
        x=a;
        while(i<nop-3)
        {
            i = i+2;
             x = x + increment;            
             even = even + func(x);
            //  cout<<setw(20)<<func(x)<<setw(20)<<x<<setw(20)<<i<<endl;
        }     
          x = a+h;           
          i=1;
        while(i<=nop-2)
        {
            odd  =  odd + func(x);
         //   cout<<setw(20)<<func(x)<<setw(20)<<x<<setw(20)<<i<<endl;
            x = x + increment;
            i=i+2;
        }
  //  cout<<setw(20)<<func(a)<<setw(20)<<func(b)<<endl;
    return((h/3)*(func(a)+func(b)+ 4*odd + 2*even) );

    } 


    
   double simpson_one_third(double B,double a, double b , double (*func)(double,double),int nop)
    {
        int i=0;
        double even=0,odd=0,even1=0,odd1=0;
        double h = (b-a)/double(nop-1);
        double x=a, increment=2*h;       
     
        i=0;
        x=a;
        while(i<nop-3)
        {
            i = i+2;
             x = x + increment;            
             even = even + func(x,B);
            //  cout<<setw(20)<<func(x)<<setw(20)<<x<<setw(20)<<i<<endl;
        }     
          x = a+h;           
          i=1;
        while(i<=nop-2)
        {
            odd  =  odd + func(x,B);
         //   cout<<setw(20)<<func(x)<<setw(20)<<x<<setw(20)<<i<<endl;
            x = x + increment;
            i=i+2;
        }
  //  cout<<setw(20)<<func(a)<<setw(20)<<func(b)<<endl;
    return((h/3)*(func(a,B)+func(b,B)+ 4*odd + 2*even) );

    } 



    double midpoint(double a, double b,double(*func)(double),int nop)
    {
        double h =(b-a)/(nop-1),sum=0;
 
        for(int i=0;i<nop;i++)
        {
           // cout<<setw(20)<<i<<setw(20)<<a<<setw(20)<<func(a)<<endl;            
            sum = sum + func(a);
            a = a+h;
        }
        sum = sum*h;
    return sum;
    }

    double trapezoid(double a, double b,double(*func)(double),int nop)
    {
        double h =(b-a)/double(nop-1),sum=0,x;
        x = a+h;
        for(int i=0;i<nop-2;i++)
        {
            sum = sum + func(x);
            x = x+h;
        }

        sum = ((func(a)+func(b))/2+ sum)*h;

    return sum;
    }


















