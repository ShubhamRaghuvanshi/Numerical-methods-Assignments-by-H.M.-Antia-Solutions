#include<iostream>
#include<iomanip>
#include<math.h>

using namespace std;

double func1(double x, double a){
    double f= x - a*sin(x) ;
  return f*f;
}
double func2(double x, double a){
  return x*sin(x);
}
double func3(double x, double a){
  double f;
  f=(x*x*x*x*x*x)-(36.0*x*x*x*x*x)+(450.0*x*x*x*x)-(2400.0*x*x*x)+(5400.0*x*x)-(4320.0*x)+720.0;
  return f;
}
double func4(double x, double a){
  double f;
  f=(x*x*x*x*x*x)-(9.2*x*x*x*x*x)+(34.45*x*x*x*x)-(66.914*x*x*x)+(70.684*x*x)-(38.168*x)+8.112+(0.0125*log(x));
  return f*f;
}


double bracket( double func(double , double ) , double a0 ,double a, double c, double t,double acc)
{
    double b,d,fa,fb,fc,fd;
    int i;   
 
    for(i=0;i<10000;i++)
    {
        b=a+(c-a)*t;
        d=c-(c-a)*t;
        if(abs(b-d)<acc) break;
        fa = func(a,a0);
        fb = func(b,a0); 
        fc = func(c,a0);
        fd = func(d,a0);     
        
        if(fd<fb)
            a=b;
        else
            c=d;
    }
return b;
}
  

void goldensearch( double func(double , double ) , double a0 , double x0 , double y0 , double nop,double acc)
{
    double  t=(3.0-sqrt(5))/2,h = (y0-x0)/nop, a=x0, c=a+h,fa,fb,fc,fd,g,fg=999999,fx;
    double  b=a+(c-a)*t,x;    
 
    for (int i=0;c<y0;i++)
    {
        fa = func(a,a0);
        fb = func(b,a0); 
        fc = func(c,a0);
              
        while( (fb> fa|| fb>fc)&&c<y0) 
        { 
            a = b;
            c = a+h;
            b=a+(c-a)*t;
            fa = func(a,a0);
            fb = func(b,a0); 
            fc = func(c,a0);           
        }        
        if(fb<fa&&fb<fc)
        {        
            x = bracket(func,a0,a,c,t,acc) ;
            fx = func(x,a0);
            cout<<"MINIMIZER = "<<setw(20)<<x<<setw(20)<<"MINIMA ="<<setw(20)<<fx<<setw(10)<<i<<endl;
            if(fg>fx)
            {  g=x;fg=fx; }
        }
        a=c;
        c=a+h; 
        b=a+(c-a)*t;
    }
    cout<<"GLOBAL MINIMIZER = "<<setw(20)<<g<<setw(20)<<"GLOBAL MINIMA ="<<fg<<endl;  
}  


 

