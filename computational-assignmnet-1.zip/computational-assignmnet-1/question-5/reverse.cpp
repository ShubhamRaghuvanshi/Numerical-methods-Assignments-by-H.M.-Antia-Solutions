#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	cout.precision(10);
	ofstream reverse;	
	reverse.open("backward.txt");
	reverse<<"					RESULTS FOR BACKWARD ITERATION"<<endl;

	
for(int n=10;n<=30;n=n+10)
{
	double j[n+1],sum=0;
	reverse<<"m = "<<n<<endl<<endl;		

	j[n]=0;
	j[n-1]=1;

	for (int m=n-1;m>0;m--)
	{
		j[m-1] = 2*m*j[m]-j[m+1];
	}

	sum= j[0];

    for (int m=2;m<=n;m=m+2)
	{
		sum = sum + 2*j[m];
	}
	for (int m=0;m<=n;m++)
	{
		reverse<<"j["<<m<<"] ="<<j[m]/sum<<endl;	
	}
	reverse<<endl<<"**************************************"<<endl;	
}


reverse.close();
	
return 0;
}
