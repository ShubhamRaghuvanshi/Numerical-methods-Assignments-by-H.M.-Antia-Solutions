#include <iostream>
#include<iomanip>

using namespace std;


double f(double t, double psi)
{
    return  ( exp(t) / (1 + exp(sqrt(t*t+1) - psi)) );
}

double F(double psi, double n, double *w , double *a, int N)
{
      double val = 0;
      for(int i = 0; i < N; i++)
        val =val+ w[i] * f(a[i], psi);      
      return (val-n);
}



double determinant(int n, double * a)
{

int i,j,k,km,l,lj=n;
double r1,t1,det;

	if(n<=0 || n>lj) return 101;
 
	
/*	Perform elimination  */
		det=1.0;
		for(k=0; k<n-1; ++k) {
/*	Find the maximum element in the Kth column  */
			r1=0.0; km=k;
			for(l=k; l<n; ++l)
				if(fabs(a[l*lj+k])>r1) {r1=fabs(a[l*lj+k]); km=l;}

			
			if(km != k) {
/*	Interchange the rows if needed  */
				for(l=k; l<n; ++l) 
				{t1=a[k*lj+l]; a[k*lj+l]=a[km*lj+l]; a[km*lj+l]=t1;}
				det=-det;
			}

			det=det*a[k*lj+k];
			if(a[k*lj+k]==0) return 121;

			for(l=k+1; l<n; ++l) {
				a[l*lj+k]=a[l*lj+k]/a[k*lj+k];
				for(i=k+1; i<n; ++i) a[l*lj+i]=a[l*lj+i]-a[l*lj+k]*a[k*lj+i];
			}
		}
		det=det*a[(n-1)*lj+n-1];
		
	
	return det;
}

double f2(double lambda, double n, double *w , double *a,int N)
{
    double A[N][N];
    for(int i=0;i<N;i++)
      for(int j=0;j<N;j++)
        {
            if(i==j)
                A[i][j] = 1.0/(i+j+1) - lambda;
            else
                A[i][j] = 1.0/(i+j+1);
        }
    return determinant(N,*A);
}

double bisect(double (*func)(double,double,double*,double*,int),double x1,double x2,double n,double *w ,double *a,int N ,int niter)
{
    int i;     
    double f1,f2,f3;
    for (i=0;i<niter;i++)
    {
        f1 = func(x1,n,w,a,N);
        f2 = func(x2,n,w,a,N);
        f3 = func((x1+x2)/2,n,w,a,N);

        if(abs(x1-x2)<1e-10)
            break;

        if(f1*f3>0)
            x1 = (x1+x2)/2;
        if(f2*f3>0)
            x2 = (x1+x2)/2;
     }   
    return x1;
}



int bisection( double (*func)(double,double,double*,double*,int),double a,double b,double n,double *w,double *a0,int N,int nop)
{
    cout.precision(10);
    double h=(b-a)/nop,x1=a,x2=a+h,x,fx;
    int root=1,ier;

    for(int i=0;i<nop;i++)
    {   
        x1 = x1+h;
        x2 = x1+h; 
        if(func(x1,n,w,a0,N)*func(x2,n,w,a0,N)>0)
            continue;
        else
        {
                x = bisect(func,x1,x2,n,w,a0,N,5000);
                fx = func(x,n,w,a0,N);
                if(abs(fx<1e-4))
                { 
                cout<<setw(5)<<"ROOT "<<root<<" = "<<x<<endl; 
                root = root+1; 
                return 0;        
                }
                else return 257;            
        }
  }
    return 257;
}




