#include<iostream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"
using namespace std;
    

 // This program is based on steepest decent method and it works good for part A of the problem .For part B I have used subroutine "NIMIF" , which is in the file main1.c

int main()
{
    int n=2,niter=10;
    double x[n],f,zero=1e-15;
    
    x[0]=1;x[1]=1;

   
   f=steepestdecent(func1,x,100,1e-10,n);
   cout<<"MINIMIZER {x1,x2} :  { "<<x[0]<<","<<x[1]<<"}   MINIMA : "<<f<<endl;
    
 
    

return 0;
}

