#include<iostream>
#include<iomanip>
#include<math.h>
#include<fstream>
using namespace std;


double func(double x , double y , double v ,double l , int q)
{
    switch (q)
    {
        case 1: return -y;
        case 2: return (2.0*x*v - l*(l+1)*y)/(1-x*x) ;
    } 
}


double rungekutta2( double (f(double,double,double,double,int)),double *Y ,double t0, double t1, int nop, double y0, double v0, double n,int qu, int choose)
{
    double k1=0,k2=0,k3=0,k4=0;
    double f1=0,f2=0,f3=0,f4=0;
    double h = (t1-t0)/double(nop),x=t0,y=y0,v=v0;
    double d = double(nop)/10.0,s;

    Y[0] = y;
    for(int i=1;i<nop;i++)
    {
        k1=h*v;
        f1=h*f(x,y,v,n,qu);

        k2=h*(v+(f1/2.0 ));
        f2=h*f(x+(h/2.0),y+(k1/2.0),v+(f1/2.0),n,qu);

        k3=h*(v+(f2/2.0));
        f3=h*f(x+(h/2.0),y+(k2/2.0),v+(f2/2.0),n,qu);

        k4=h*(v+f3);
        f4=h*f(x+h,y+k3,v+f3,n,qu);

        v=v+(f1+2.0*f2+2.0*f3+f4)/6.0;

        y=y+(k1+2.0*k2+2.0*k3+k4)/6.0;
        Y[i]=y;
        x=x+h;
    }
      
    if(choose==1) return v;
    if(choose==0) return y;
}

void boundary( double (f(double,double,double,double,int)) ,double t0 , double t1 , int nop , double yi,double yf,double n , int qu ,double *y)    
{
    double y1a=yi,v1a=0,y2a=0,v2a=yf;
    double y1b,y2b,solution;
    double *y1,*y2;
    int k=0;

   
    y1 = new double [nop];
    y2 = new double [nop];
   
    y1b = rungekutta2(f,y1,t0,t1,nop,y1a,v1a,n,qu,0); 
    y2b = rungekutta2(f,y2,t0,t1,nop,y2a,v2a,n,qu,0); 
  
   
 // Y IS LINEAR COMBINATION OF Y1 AND Y2 SUCH THAT IT SATISFIES THE GIVEN 
//BOUNDARY CONDITIONS    
    cout<<"  CALCULATED VALUE "<<setw(20)<<"t"<<endl;
    cout<<"    "<< y1[0] + ( yf -y1b)*y2[0]/y2b<<setw(34)<<t0<<endl;
    cout<<"    "<< y1[nop-1] + ( yf -y1b)*y2[nop-1]/y2b<<setw(34)<<t1<<endl;
    
   for(int i=0;i<nop;i++)
    y[i] =  y1[i] + ( yf -y1b)*y2[i]/y2b;

    delete []y1;    
    delete []y2;
    
}




//double rungekutta2( double (f(double,double,double,double,int)) ,double t0, double t1, int nop, double y0, double v0, double n,int qu)











