#include<iostream>
using namespace std;

double interp(double p , double *fx, double *x,int nop,double a)
{
	

	double df[nop][nop-1],fox = fx[0],product=1;
	
	for(int i=0;i<nop;i++)
		for(int j=0;j<nop-i-1;j++)
			if(i==0)
				df[j][i] = (fx[j+1]-fx[j])/(x[j+1]-x[j]);
			else
				df[j][i] = (df[j+1][i-1] -df[j][i-1])/(x[j+1+i]-x[j]); 
		
	for(int i=0;i<nop-1;i++)
	{
		product = product*(p - x[i]);		
		fox = fox + product*df[0][i];
	}
		
	return fox;
}
