#include<iomanip>
#include<iostream>
#include<math.h>
using namespace std;

double func1(double x)
{
    return exp(x);
}

double func3(double x)
{
    return exp(x)*exp(x);
}

double func2(double x)
{
    return exp(x) - (1+x) ;
}

double func4(double x)
{
    return ( (exp(x) - (1+x))*(exp(x) - (1+x)));
}

double func5(double x)
{
    return ( (exp(x))/(1+x)*3/2 );
}

double func6(double x)
{
    return ( 1.5*exp(2*x)/(1+x) ) ;
}


double monte_carlo_integration(double a, double b , int nop , double(*func)(double) ,int Rand )
{
    double x,sum=0;
  //  RAND_MAX=1;
    for(int i=0;i<nop;i++)
    {
        x = double(rand())/double(RAND_MAX);
        x = (b-a)*x + a;
        if(Rand==1)
            x = -1 + sqrt(1 +3*x) ;

        sum = sum + func(x);
    }
return (b-a)*sum/nop;
}
