#include<iostream>
#include<fstream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"
using namespace std;



int main()
{


	ofstream f1_4p_u,f1_10p_u,f1_20p_u;	
	ofstream f2_4p_u,f2_10p_u,f2_20p_u;
	ofstream f3_4p_u,f3_10p_u,f3_20p_u;   
	
	ofstream f1_4p_c,f1_10p_c,f1_20p_c;	
	ofstream f2_4p_c,f2_10p_c,f2_20p_c;
	ofstream f3_4p_c,f3_10p_c,f3_20p_c;   

	f1_4p_u.open("f1_4p_u.txt");
	f1_10p_u.open("f1_10p_u.txt");
	f1_20p_u.open("f1_20p_u.txt");

	f2_4p_u.open("f2_4p_u.txt");
	f2_10p_u.open("f2_10p_u.txt");
	f2_20p_u.open("f2_20p_u.txt");
	
	f3_4p_u.open("f3_4p_u.txt");
	f3_10p_u.open("f3_10p_u.txt");
	f3_20p_u.open("f3_20p_u.txt");

	f1_4p_c.open("f1_4p_c.txt");
	f1_10p_c.open("f1_10p_c.txt");
	f1_20p_c.open("f1_20p_c.txt");

	f2_4p_c.open("f2_4p_c.txt");
	f2_10p_c.open("f2_10p_c.txt");
	f2_20p_c.open("f2_20p_c.txt");
	
	f3_4p_c.open("f3_4p_c.txt");
	f3_10p_c.open("f3_10p_c.txt");
	f3_20p_c.open("f3_20p_c.txt");




	float a=-1,b=1,point,temp1,temp2;	
	float *df;

	for(int flag=0;flag<=1;flag++)
	{

	if(flag==1)
	{
		cout<<endl<<"FOR CHEBESHEV POINTS";
		cout<<endl<<"			          sin(x)                  1/(1+25*x*x)	            sqrt(1+x)"<<endl<<endl;
	}	

	else
	{
		cout<<endl<<"FOR EQUALLY SPACED POINTS";
		cout<<endl<<"			          sin(x)                 1/(1+25*x*x)	            sqrt(1+x)"<<endl<<endl;
	}

	for(int nop=2;nop<=20;nop= nop+2)
	{
		float x[nop], fx1[nop],fx2[nop],fx3[nop];
		x[0]=a;
  		temp1=0;
	
		if(flag==0)	
			for(int i=1;i<nop;i++) 
	  		{
				x[i] = x[i-1] +(b-a)/float(nop-1);
			}
		else
			for(int i=0;i<nop;i++) 
	  		{	
				x[i] =  cos((2*i+1)*M_PI/float(2*nop));

			}

		for(int i=0;i<nop;i++) 
  		{
			fx1[i] = sin(x[i]);
			fx2[i] = 1.0/(1+25*x[i]*x[i]);
			fx3[i] = sqrt(1+x[i]);
	    }

		df= difftable(fx1,x,nop);	
		for(point=a;point<=b;point = point+0.001)  
		{
			temp2= sin(point);			
			if(temp1<abs(interpolate(nop,df,fx1[0],point,x)-temp2))
				temp1 = abs(interpolate(nop,df,fx1[0],point,x)-temp2);
			
				if(nop==4&&flag==0)		
					f1_4p_u<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl;
				if(nop==4&&flag==1)		
					f1_4p_c<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl;
							
				if(nop==10&&flag==0)		
					f1_10p_u<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl;
				if(nop==10&&flag==1)		
					f1_10p_c<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl;
										
				if(nop==20&&flag==0)		
					f1_20p_u<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl;
				if(nop==20&&flag==1)		
					f1_20p_c<<point<<"	"<<abs(interpolate(nop,df,fx1[0],point,x)-temp2)<<endl; 

			
		}
		cout<<scientific<<"MAXIMUM ERROR FOR n  = "<<setw(3)<<nop<<setw(18)<<temp1; 
	
		df= difftable(fx2,x,nop);	
		temp1=0;		
		for(point=a;point<=b;point = point+0.001)  
		{
			temp2 = 1/(1+25*point*point);
			if(temp1<abs(interpolate(nop,df,fx2[0],point,x)-  1/(1+25*point*point) ))
				temp1 =abs(interpolate(nop,df,fx2[0],point,x)-  1/(1+25*point*point) );
	
			if(nop==4&&flag==0)
				f2_4p_u<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)-  temp2 )<<endl;
			if(nop==4&&flag==1)
				f2_4p_c<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)-  temp2 )<<endl;
		
			if(nop==10&&flag==0)
				f2_10p_u<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)- temp2 )<<endl;
			if(nop==10&&flag==1)
				f2_10p_c<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)- temp2 )<<endl;
			
			if(nop==20&&flag==0)
				f2_20p_u<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)-  temp2 )<<endl;
			if(nop==20&&flag==1)
				f2_20p_c<<point<<"	"<<abs(interpolate(nop,df,fx2[0],point,x)-  temp2 )<<endl;
	

		}
		cout<<setw(25)<<temp1;

		df= difftable(fx3,x,nop);	
		temp1=0;		
		for(point=a;point<=b;point = point+0.001)  
		{
			temp2=sqrt(1+point);
			if(temp1<abs(interpolate(nop,df,fx3[0],point,x)-  sqrt(1+point)))
				temp1 = abs(interpolate(nop,df,fx3[0],point,x)-  sqrt(1+point));

			if(nop==4&&flag==0)			
				f3_4p_u<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl;
			if(nop==4&&flag==1)			
				f3_4p_c<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl;

			
			if(nop==10&&flag==0)			
				f3_10p_u<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl;
			if(nop==10&&flag==1)			
				f3_10p_c<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl;

			if(nop==20&&flag==0)			
				f3_20p_u<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl;
			if(nop==20&&flag==1)			
				f3_20p_c<<point<<"	"<<abs(interpolate(nop,df,fx3[0],point,x)-  temp2)<<endl; 


		}
		cout<<setw(25)<<temp1<<endl;  
	
	

	} //for(int nop=2;nop<=20;nop= nop+2)

}


		f1_4p_u.close();
		f2_4p_u.close();
		f3_4p_u.close();
		f1_4p_c.close();
		f2_4p_c.close();
		f3_4p_c.close();
			
		f1_10p_u.close();
		f2_10p_u.close();
		f3_10p_u.close();
		f1_10p_c.close();
		f2_10p_c.close();
		f3_10p_c.close();
	
		f1_20p_u.close();
		f2_20p_u.close();
		f3_20p_u.close();
		f1_20p_c.close();
		f2_20p_c.close();
		f3_20p_c.close();

	
 
return 0;
}
