/*	to calculate weights and abscissas of Gauss-Laguerre quadrature formulas
	with weight function  x**alp * exp(-x) */

#include <stdio.h>
#include <math.h>
#include <iostream>
using namespace std;
int lagurw(int n, double alp, double w[], double a[]);
int tql2(double *z, int n, int iz, double d[], double e[], double reps);
int gausrc(int n, double w[], double a[], double *cof, double ri0);

int lagurw_list(double *a, double *w, double alp, int nuse)
{
	int i,i1,j, id, iflg, ier,np;
	double beta,  ri0;


	for(i1=0; i1<99; ++i1) {
//		printf("type  nuse = No. of points in quadrature formula,  alp \n");
//		printf("                        (quits when n<=0)\n");
//		scanf(" %d %le", &nuse,&alp);
		if(nuse<=0) return 0;
		i=lagurw(nuse,alp,w,a);
		if(i != 0) break;
/*		printf(" ier = %d  n = %d    alp = %e  \n", i,nuse,alp);*/
/*		printf("  Abscissas             Weights  \n");*/
/*		for(i=0; i<nuse; ++i) printf(" %20.13e %20.13e \n",a[i],w[i]);*/
	}
	return i;
}

//int main(){
//  double *a = new double [10];
//  double *w = new double [10];
//	int s = lagurw_list(a, w, 0, 5);
//	cout<<"\n"<<s<<"\n";
//	for(int i = 0; i < 5; i++){
//		cout<<a[i]<<" , "<<w[i]<<endl;
//	}
//}


/*	To calculate weights and abscissas of a quadrature formula with
	specified weight function when recurrence relation for orthogonal
	polynomial is known.

	N : (input) Number of points in the required quadrature formula
	W : (output) Array of length N, which will contain the weights
	AB : (output) Array of length N containing the abscissas
	COF : (input) Array of length 3*N containing the coefficients of
		the recurrence relation for orthogonal polynomials
		P_i(x)=(COF[3*i]*x+COF[3*i+1])P_{i-1}(x) - COF[3*i+2]*P_{i-2}(x)
	RI0 : (input) The integral of weight function over the required interval.

	Error status is returned by the value of the function GAUSRC.
		0 value implies successful execution
		302 implies N<=0
		321 implies that some coefficient becomes imaginary
			during calculations.
		In both these cases calculations are abandoned.
		Other values may be set by TQL2

     Required functions : TQL2
*/

#include <math.h>
#include <stdlib.h>

int tql2(double *z, int n, int iz, double d[], double e[], double reps);

int gausrc(int n, double w[], double ab[], double *cof, double ri0)

{
	int i,j,ier;
	double r1,reps=1.0e-15;
	double *wk,*d,*e;

	if(n<=0) return 302;
	wk=(double *) calloc((size_t) (n*n), sizeof(double));
	d=(double *) calloc((size_t) n, sizeof(double));
	e=(double *) calloc((size_t) n, sizeof(double));

/*     Calculate the coefficients of symmetric tridiagonal matrix */
	for(i=0; i<n; ++i) {
		d[i]=-cof[3*i+1]/cof[3*i];
		if(i<n-1) {
			r1=cof[3*i+5]/(cof[3*i]*cof[3*i+3]);
			if(r1>=0.0) e[i+1]=sqrt(r1);
			else {free(e); free(d); free(wk); return 321;}
		}
		for(j=0; j<n; ++j) wk[j+i*n]=0.0;
		wk[i+i*n]=1.0;
	}

/*     Find eigenvalues and eigenvectors of the tridiagonal matrix */
	ier=tql2(wk,n,n,d,e,reps);
	if(ier>0) {free(e); free(d); free(wk); return ier;}

/*     Calculate the abscissas and weights */
	for(i=0; i<n; ++i) {
		ab[i]=d[i];
		w[i]=wk[i]*wk[i]*ri0;
	}
	free(e); free(d); free(wk);
	return 0;
}



/*     To calculate weights and abscissas of a Gauss-Laguerre quadrature formula

	N : (input) Number of points in the required quadrature formula
	ALP : (input) Exponent of x in weight function, w(x)=x**ALP*EXP(-x)
	W : (output) Array of length N, which will contain the weights
	A : (output) Array of length N containing the abscissas

	Error status is returned by the value of the function LAGURW.
		0 value implies successful execution
		302 implies N<= 0
		313 implies ALP<= -1
		321 implies that some coefficient becomes imaginary
			during calculations.
		In both these cases calculations are abandoned.
		Other values may be set by TQL2

	Required functions : GAUSRC, TQL2, GAMMA
*/

#include <math.h>
#include <stdlib.h>

int gausrc(int n, double w[], double a[], double *cof, double ri0);

int lagurw(int n, double alp, double w[], double a[])

{
	int i,ier;
	double ri0;
	double *wk;

	if(alp<= -1) return 313;

	ri0=gamma(alp+1.0);
	wk=(double *) calloc((size_t) (3*(n+1)), sizeof(double));

/*     Coefficients of recurrence relation */
	for(i=0; i<=n; ++i) {
		wk[i*3]=-(alp+i+1.0)/(i+1.0);
		wk[1+i*3]=(2*i+1.0+alp)*(alp+i+1.0)/(i+1.0);
		wk[2+i*3]=(i+alp)*(i+alp)*(i+1+alp)/(i+1.0);
	}

	ier=gausrc(n,w,a,wk,ri0);
	free(wk);
	return ier;
}



/*	To calculate Gamma function for any real value of XG
	Use GAMMALN for calculating the logarithm of Gamma function
	which may be useful for large arguments or when argument is
	close to a negative integer.

	Required functions : None
*/

#include <math.h>

/*	PIS is SQRT(2*PI) */
#define PI 3.14159265358979323846
#define PIS 2.5066282746310005024

double gamma(double xg)

{
	double x,gx,f,y,rmk,f1,x1,fn,fd;

/*	The coefficients for rational function approximations */
	double a[2] ={1.767971449569122937e+00,  2.909421117928672645e-01};
	double b[3] ={8.333333333333231537e-02,  1.445531763554246280e-01,
                      2.012779361583001035e-02};
	double a1[6] ={3.905731686764559737e+03,  2.204952264401381785e+03,
                      -1.932467485468849660e+03,  4.643360871045442213e+02,
                      -4.818088806916028754e+01,  1.896853765546068169e+00};
	double b1[7] ={3.918055655523400310e+03, -1.088116266563809683e+02,
                       8.203258626193993149e+02, -9.289402000761705906e+01,
                       6.521113026294866877e+01, -6.090618615608719044e+00,
                       1.475909104740280784e+00};

	x=fabs(xg);
	if(x>1000.0) {
/*	Use asymptotic approximation (Stirling formula) */
        gx=(1+1.0/(12*x)+1./(288*x*x)-139.0/(51840*x*x*x)-571.0/(2488320e0*x*x*x*x));
		f=pow(x,x-0.5)*exp(-x)*PIS*gx;
	}

	else if(x>8.0) {
/*	Use rational function approximation for Log(Gamma)  */
		y=1.0/(x*x);
        rmk=((b[2]*y+b[1])*y+b[0])/((a[1]*y+a[0])*y+1);
		f=pow(x,x-0.5)*exp(-x)*PIS*exp(rmk/x);
	}
	else if(x>=2.0) {
/*	Use rational function approximation for (Gamma) over [2,3]
	after translating the range if necessary */
		f1=1.0; x1=x;
		while(x1>3.0) {
			f1=f1*(x1-1.0);
			x1=x1-1.0;
		}

		if(x1==3) f=f1*2.0;
		else if(x1==2) f=f1;

		fn=(((((b1[6]*x1+b1[5])*x1+b1[4])*x1+b1[3])*x1+b1[2])*x1+b1[1])*x1+b1[0];
		fd=(((((a1[5]*x1+a1[4])*x1+a1[3])*x1+a1[2])*x1+a1[1])*x1+a1[0])*x1+1;
		f=f1*fn/fd;
	}
	else if(x>0.0) {
/*	Use rational function approximation for (Gamma) over [2,3]
	after translating the range if necessary */
		f1=1./x;
		x1=x+1.0;
		if(x<1) {f1=f1/x1; x1=x1+1.0;}
		if(x1==2) f=f1;

		fn=(((((b1[6]*x1+b1[5])*x1+b1[4])*x1+b1[3])*x1+b1[2])*x1+b1[1])*x1+b1[0];
		fd=(((((a1[5]*x1+a1[4])*x1+a1[3])*x1+a1[2])*x1+a1[1])*x1+a1[0])*x1+1;
		f=f1*fn/fd;
	}

	if(xg>0.0) return f;
	f=PI/(xg*sin(PI*x)*f);
	return f;
}



/*	To find eigenvalues and eigenvectors of Z T Z^T using QL algorithm
	where T is a symmetric tridiagonal matrix and Z is an orthogonal matrix.
	If Z is the transformation matrix to reduce original matrix to
	tridiagonal matrix, it will calculate the eigenvectors of original matrix

	Z : (input/output) Array of length IZ*N which should contain
		the transformation matrix required to reduce original real
		symmetric matrix to tridiagonal form. To find eigenvectors
		of a symmetric tridiagonal matrix, set Z to unit matrix.
		After execution Z will contain the eigenvector of the original
		matrix Z T Z^T. Z[i][j] should contain the ith component of
		jth eigenvector
	N : (input) Order of matrix
	IZ : (input) The second dimension of array Z as declared in the
		calling function. (IZ>=N)
	D : (input/output) Array of length N, containing the diagonal
		elements of the tridiagonal matrix, D[i]=T[i][i]
		After execution it will contain the eigenvalues of the matrix
	E : (input/output) Array of length N containing the off-diagonal
		elements of the tridiagonal matrix, E[i]=T[i][i+1]=T[i+1][i]
		It is used as scratch space and its contents will be destroyed
		during execution.
	REPS : (input) Required tolerance, it should be of order of machine
		accuracy

	Error status is returned by the value of the function TQL2.
		0 value implies successful execution
		108 implies that N<=1 or N>IZ, in which case no
			calculations are performed
		143 implies that the QL algorithm failed to converge
			for some eigenvalue, the calculations are abandoned

	Required functions : None
*/

#include <math.h>

int tql2(double *z, int n, int iz, double d[], double e[], double reps)

{
	int i,j,k,l,m,it, nit=30;
	double b,f,g,h,p,r,c,s;

	if(n<=0 || n>iz) return 108;

	for(i=1; i<n; ++i) e[i-1]=e[i];
	e[n-1]=0.0;
	b=0.0; f=0.0;

	for(l=0; l<n; ++l) {
		h=reps*(fabs(d[l])+fabs(e[l]));
		if(b<h) b=h;
/*	Look for small off-diagonal elements */
		for(i=l; i<n; ++i) {
			m=i;
			if(fabs(e[m])<=b) break;
		}
		if(m==l) {
/*	one eigenvalue is isolated */
			d[l]=d[l]+f;
			goto nextit;
		}

/*	Loop for QL transformation  */
		for(it=1; it<=nit; ++it) {
/*	Find shift */
			g=d[l];
			p=(d[l+1]-g)/(2.0*e[l]);
			r=sqrt(p*p+1.0);
			if(p<0.0) r=-r;
			d[l]=e[l]/(p+r);
			h=g-d[l];
			for(i=l+1; i<n; ++i) d[i]=d[i]-h;
			f=f+h;

/*	The QL transformation */
			p=d[m];
			c=1.0; s=0.0;
/*	Given's rotations */
			for(i=m-1; i>=l; --i) {
				g=c*e[i];
				h=c*p;
				if(fabs(p)>=fabs(e[i])) {
					c=e[i]/p;
					r=sqrt(c*c+1.0);
					e[i+1]=s*p*r;
					s=c/r;
					c=1.0/r;
				}
				else {
					c=p/e[i];
					r=sqrt(c*c+1.0);
					e[i+1]=s*e[i]*r;
					s=1.0/r;
					c=c/r;
				}
				p=c*d[i]-s*g;
				d[i+1]=h+s*(c*g+s*d[i]);

/*	Transforming the eigenvectors */
				for(k=0; k<n; ++k) {
					h=z[i+1+k*iz];
					z[i+1+k*iz]=s*z[i+k*iz]+c*h;
					z[i+k*iz]=c*z[i+k*iz]-s*h;
				}
			}
			e[l]=s*p;
			d[l]=c*p;
			if(fabs(e[l])<=b) {
/*	One eigenvalue is isolated */
				d[l]=d[l]+f;
				goto nextit;
			}
		}
/*	QL iteration fails to converge */
		return 143;

nextit: b=b;
	}

/*	Sort eigenvalues in ascending order by straight selection */
	for(i=0; i<n-1; ++i) {
		k=i;
		p=d[i];
		for(j=i+1; j<n; ++j) {
			if(d[j]<p) {k=j; p=d[j];}
		}
		if(k != i) {
/*	exchange the eigenvalues and eigenvectors */
			d[k]=d[i];
			d[i]=p;
			for(j=0; j<n; ++j) {
				p=z[i+j*iz]; z[i+j*iz]=z[k+j*iz]; z[k+j*iz]=p;
			}
		}
	}
	return 0;
}

