#include<iostream>
#include<math.h>
using namespace std;

int main()
{
	cout.precision(8);
	float a[] = {1.3*pow(10,-3),3.1*pow(10,-3),1.21,4.36,1.23,4.36*pow(10,32),4.23*pow(10,-32)};
	float b[] = {12345.68,-23536.9,5.082,1.87,2.62,1.87*pow(10,32),1.66*pow(10,32)};
	float c[] = {3.82*pow(10,-4),1.23*pow(10,-4),5.3361,3.43,1.395203,3.43*pow(10,32),3.21*pow(10,32)};
	float d;
	int flag;

	


	for(int i=0;i<7;i++)
	{
		d = b[i]*b[i]-4*a[i]*c[i];  //Descriminant
	
		if(d>0)
			{
				flag=1;	
				cout<<endl<<"REAL DISTINCT ROOTS"<<endl;			
			}
		else if(d<0)
			{
				d = -d;
				flag =0;
				cout<<endl<<"COMPLEX ROOTS"<<endl;		
			}
		else
			{
				cout<<endl<<"EQUAL ROOTS"<<endl;
				flag =1;		
			}

		if(flag==1)
		{	cout<<endl<<"FOR  a	= "<<a[i]<<"	b = "<<b[i]<<" c = "<<c[i]<<endl;
			
			cout<<endl<<"		x1 = "<<(-b[i]+sqrt(d))/(2*a[i])<<endl;
			cout<<"		x2 = "<<(-b[i]-sqrt(d))/(2*a[i])<<endl;
		}
		else if(flag==0)
		{
			cout<<endl<<"FOR  a	= "<<a[i]<<"	b = "<<b[i]<<" c  = "<<c[i]<<endl;
			cout<<endl<<"		x1 = "<<-b[i]/(2*a[i])<<"+"<<sqrt(d)/(2*a[i])<<"i"<<endl;	
			cout<<"		x1 = "<<-b[i]/(2*a[i])<<"-"<<sqrt(d)/(2*a[i])<<"i"<<endl;
		}
		
	}		
			


return 0;
}

