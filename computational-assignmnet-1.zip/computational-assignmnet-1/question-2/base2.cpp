#include<iostream>
#include"basen.h"
#include<math.h>
#include<time.h>

using namespace std;


void merssene()
{

	clock_t time;
	time = clock();
	number b(1000000000,21702,726,0),c(1000000000,21702,726,0);
	c==1;
	b==1;
	for(int i=1;i<21702;i++)
	{
		b = b*2;
		
	}
		b = b-c;
	time = clock()-time;
		b.display();	
cout<<endl<<endl<<"time ="<<time<<endl;
}
int main()
{

	int decimal=11,precision=5,signbit=0,signbitb=1;
	long int base=10;
	number a(base,decimal,precision,signbit);	

	//a.randomnumber();
	//a.display();
	//(a*9).display();



merssene();
	return 0;
}
