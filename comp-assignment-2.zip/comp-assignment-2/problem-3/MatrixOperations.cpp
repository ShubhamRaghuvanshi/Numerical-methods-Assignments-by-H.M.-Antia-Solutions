#include<iostream>
#include<iomanip>
#include<time.h>
#include<math.h>
#include<stdlib.h>
#include "MatrixOperarions.h"

using namespace std;




	matrix::matrix(int r,int c) //constructor of the matrix class
		{
			maxrow=r; maxcol=c;
			ptr= new double[r*c]; /*allocates the memory of size
					   r*c and allocates the adrress
					   to pointer "ptr" */
		}


	matrix::matrix(int r) //constructor of the matrix class
		{
			maxrow=r; maxcol=r;
			ptr= new double[r*r]; /*allocates the memory of size
					   r*c and allocates the adrress
					   to pointer "ptr" */
		}


    void matrix::setcomp(int i,int j,double value)
		{
 			ptr[i*maxcol+j]=value;
			
		}

	


	void matrix::display() //to display the matrix
		{
			int i,j,mat_off;

			for (i=0;i<maxrow;i++)
			{
				cout<<endl;
				for (j=0;j<maxcol;j++)
				 cout<<setw(15)<<ptr[i*maxcol+j];
			}cout<<endl<<endl;
		}






	matrix matrix::operator*(matrix b) //matrix multiplication
		{
			matrix c(maxrow,b.maxcol);
			int i,j,k,mat_off1,mat_off2,mat_off3;


			if (maxcol!=b.maxrow)
			{
				cout<<"DIMENTION MISMATCH CANNOT MULTIPLY"<<endl;
				return c;
			}

			for (i=0;i<c.maxrow;i++)
			{
				for (j=0;j<c.maxcol;j++)
				{
					mat_off3 =i*c.maxcol+j;
					c.ptr[mat_off3] =0;

					for (k=0;k<maxcol;k++)
					{
						mat_off2 =k*b.maxcol+j;
						mat_off1 =i*maxcol+k;
						c.ptr[mat_off3] += ptr[mat_off1]*b.ptr[mat_off2];
						
					}
				}
			}
			return(c);
		}







	

	matrix matrix::transpose() //transpose of matrix
		{
			int i,j,mat_off,mat_off1;
			double temp;
			matrix c(maxcol,maxrow);

			for (i=0;i<maxrow;i++)
			{
				for (j=0;j<maxcol;j++)
				{
					mat_off = i*maxcol+j;
					mat_off1= j*maxrow+i;
					temp = ptr[mat_off];
					c.ptr[mat_off1]=temp;
				}
			}
		return c;
		}




	void matrix::identitymatrix(int r,int c) //identity matrix I[r,c]
		{
			int mat_off;
			int i,j;

			for (i=0;i<r;i++)
			{
				for (j=0;j<c;j++)
				{
					mat_off = i*maxcol+j;
					if (i==j)
						ptr[mat_off]=1.0;
					else
						ptr[mat_off]=0.0;
				}
			}
		}







	matrix identity(int order) //square identity matrix I[o,o]
		{
			int i,j,mat_off;
			matrix m(order);
			m.identitymatrix(order,order);

			return m;
		}

	 double* matrix::getpointer() //get the pointer of matrix object
		{
		return (ptr);
		}




	matrix matrix::gibbins(int row1,int row2,double c,double s)

		{

			matrix m(maxrow,maxcol);
			m.identitymatrix(maxrow,maxcol);

			if (row1>maxrow || row2>maxrow)
				{cout<< "INPUT ROW OR COLUMN IS GREATER THAN INPUT MATRIX ROW OR COLUMN"<<endl;
				return m;}

			else
			{
				m.ptr[row1*m.maxcol+row1] = c;
				m.ptr[row2*m.maxcol+row2] = c;
				m.ptr[row1*m.maxcol+row2] = s;
				m.ptr[row2*m.maxcol+row1] = -s;
				return m;
			}
		}



	double matrix::getcomp(int row,int col) //get matrix component
		{
			int mat_off;
			double s;
			mat_off = row*maxcol+col;
			s = ptr[mat_off];
			return s;
		}


		matrix matrix::getcolumn(int col) //get column of the matrix
		{
			int i,mat_off,mat_off1;
			matrix column(maxrow,1);

			for (i=0;i<maxrow;i++)
			{
				mat_off = i*maxrow + col;
				mat_off1 = i;
				column.ptr[mat_off1] =ptr[mat_off];
			}
		return column;
		}

	matrix matrix::eigen(matrix A,int order,int flag)
		{
			int i,j,k,col=1;
			double *ptra,*ptrq,x,y,det;
			matrix Q(order),G(order),R(order),vector(order),values(order),Acopy(order);		
			
	
			Acopy = A;
			vector = identity(order);
			values = identity(order);

			for (j=0;j<200;j++)
			{
				Q = identity(order);
				R = A;
				for (k=0;k<order-1;k++)
				{
					for(i=k+1;i<order;i++)
					{
						ptra =R.getpointer();
						x=*(ptra + k*order +k);
						y=*(ptra + i*order +k);
						if (x==0&&y==0)
						continue;

						G= A.gibbins(k,i,x/sqrt(x*x+y*y),y/sqrt(x*x+y*y));
						R = G*R;
						Q = G*Q;
					}
				}
				Q =Q.transpose();
				vector = vector*Q;
				A = R*Q;
			}

			for(i=0;i<maxrow;i++)
			{
					if(A.ptr[i*maxcol+i]<pow(10,-12))
			        	values.setcomp(i,i,0);	
					else				
						values.setcomp(i,i,A.getcomp(i,i));	
			}


			if (flag ==0)
		     return vector;
			else if(flag ==1)
			 return values;			

			}

		void matrix::svd(matrix A,matrix U,matrix sigmasq,matrix V,matrix b)
		{
			int rank=maxcol;
			matrix x(maxcol);
			U = A*(A.transpose());
			V = (A.transpose())*A;	
			sigmasq = sigmasq.eigen(U,maxcol,1);	
			U=U.eigen(U,maxcol,0);
			V=V.eigen(V,maxcol,0);
		
			
			for(int i=0;i<V.maxrow;i++)
			{
				for(int j=0;j<V.maxcol;j++)
				{
					if(abs(V.getcomp(i,j))<pow(10,-10))
						V.setcomp(i,j,0);
					if(abs(U.getcomp(i,j))<pow(10,-10))
						U.setcomp(i,j,0);	
				}

			}		

		
			for(int i=0;i<sigmasq.maxrow;i++)
				sigmasq.ptr[i*sigmasq.maxcol+i] = sqrt(sigmasq.ptr[i*sigmasq.maxcol+i]);	
 
			cout<<"U :"<<endl;				
			U.display();
			cout<<"SIGMA :"<<endl;
			sigmasq.display();
			cout<<"v :"<<endl;
			V.transpose().display();
			
				for(int i=0;i<sigmasq.maxrow;i++)
				{
					if( sigmasq.ptr[i*sigmasq.maxcol+i]!=0)
						{sigmasq.ptr[i*sigmasq.maxcol+i] = 1/(sigmasq.ptr[i*sigmasq.maxcol+i]);
						}
					else
                       rank--;
				}
			
	
			

			cout<<"null space for this matrix is "<<endl<<endl;
			V.getcolumn(3).display();

			cout<<"range for this matrix is"<<endl<<endl;
		
			for(int i=0;i<maxcol;i++)
			{
				for(int j=0;j<rank;j++)
				{
					cout<<setw(13)<<U.ptr[i*maxcol+j]<<"		";
				}cout<<endl;
			}cout<<endl;
			
				
			cout<<"least square solution for the vector:"<<endl<<endl;	
			b.display();
			cout<<"is :"<<endl<<endl;
			x = V*sigmasq*(U.transpose())*b;
			for(int i=0;i<maxrow;i++)
			{
				cout<<"		"<<setw(10)<<V.ptr[i*maxcol+3]<<"*x +"<<x.ptr[i]<<endl;
			} 			
			
			cout<<"********************************************************************"<<endl;

       }
		


	







