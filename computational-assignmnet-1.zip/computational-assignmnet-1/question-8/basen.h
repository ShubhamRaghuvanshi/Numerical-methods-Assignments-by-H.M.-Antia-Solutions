
class number
{	
	private:
		int dec,pr,*ptr,overflow,sign;
	 int base;
	public: 
		number(int b,int d,int p,int signbit);
		~number();
		void getnum();
		void display();
		void randomnumber();
		number addnum(number n,int *carry);
		
		number operator + (number n);
		number operator == (int n);
		number operator - (number n);
		number operator * (int n);
		int operator > (number n);
		number multiply(number n,int precision);
		number divide(int denominator,int precision);	
		number appendleft(int n);
		number appendright(int n);
		number arctan();
		number merssene();				

		number complement();
		void leftshift();	
		void rightshift();
		void leftshift(int n);
		void rightshift(int n);
		
		int getint();		
};

		
