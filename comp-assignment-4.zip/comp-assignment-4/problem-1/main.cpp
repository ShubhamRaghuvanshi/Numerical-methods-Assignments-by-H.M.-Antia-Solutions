#include<iostream>
#include<math.h>
#include<iomanip>
#include"functions.cpp"

using namespace std;

int main()
{
    
    double a=0,b=1;
    int nop;

    //PART 1
        nop = 524033;
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 1"<<endl;

        
        cout<<setprecision(12)<<"INTEGRATION = "<<simpson_one_third(a,b,func1,nop)<<setw(20)<<endl;
          
        //PART 2
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 2"<<endl;      
        nop= 1025;
        a = 1/double(nop);
        cout<<setprecision(12)<<"INTEGRATION = "<<simpson_one_third(a,b,func2,nop)<<setw(20)<<endl; 

    //PART 3
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 3"<<endl; 
        nop = 16777217;
        a = 1/double(nop);
        cout<<setprecision(12)<<"INTEGRATION = "<<simpson_one_third(a,b,func3,nop)<<endl;  
    
    //PART 4
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 4"<<endl; 

        nop=257;                
        a=0;b=1;
        cout<<setprecision(12)<<" ERF(1)  :  "<<simpson_one_third(a,b,func4,nop)<<endl;
        b=5;
        cout<<setprecision(12)<<" ERF(5)  :  "<<simpson_one_third(a,b,func4,nop)<<endl;
        b=10;
        cout<<setprecision(12)<<" ERF(10) :  "<<simpson_one_third(a,b,func4,nop)<<endl;
   

    //PART 5    
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 5"<<endl; 
        nop=1001;
        double alpha[4] = {0.2,0.1,0.01,0.002};
        for(int j=0;j<4;j++)
        {
            nop = nop*10+1; 
           cout<<setprecision(12)<<"INTEGRATION = "<<simpson_one_third(alpha[j],b,func5,nop)<<endl;
        }
         
    //PART 6
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 6"<<endl; 
        nop=257;
        double B[] = {2,1.1,1.01,1.001,1.0001};
        a=0;b=1;
    
        for(int i=0;i<5;i++)
        {
         cout<<setprecision(12)<<setw(20)<<"1/sqrt(("<<B[i]<<")^2 -1) "<<setw(20)<<simpson_one_third(B[i],a,b,func6,nop)<<endl;  
           nop = (nop-1)*2+1;
        }   

     //PART 7
        cout<<endl<<"***********************"<<endl;
        cout<<"PART 7"<<endl; 
        nop=131039;
   
        a = 0.1;b=0.2;
           
        cout<<setprecision(12)<<"INTEGRATION = "<<simpson_one_third(a,b,func7,nop)<<endl;  
        
       

return 0;
}
