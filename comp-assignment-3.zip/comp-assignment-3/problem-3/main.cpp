#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"

using namespace std;

int main()
{

float dist[] = {100,200,400,800,1500,5000,10000,30000} ,*df;
float Time[] = {9.58,19.19,43.03,100.91,206,757.35,1577.53,5207.4 };
float points[] = {1000,2000,25000,42195};
float actual[] = {131.96, 284.79, 4345 ,7377};

	cout<<"	POINT OF ESTIMATION 	ESTIMATED VALUE		ACTUAL VALUE"<<endl;

//float *difftable(float *fx, float *x,int nop,float a)
//float interpolate(int nop , float *df, float fx0,float p ,float *x)


	df = difftable(Time,dist,8);
	for(int i=0;i<4;i++)
	{
		cout<<setw(20)<<points[i]<<setw(25)<<interpolate(8,df,Time[0],points[i],dist)<<setw(20)<<actual[i]<<endl;
		
	} 

		df = difftable(dist,Time,8);
	cout<<endl<<"DISTANCE FOR INE HOUR"<<setw(25)<<interpolate(8,df,dist[0],36000,Time)<<setw(20)<< 21285<<endl<<endl; 

	for(int i=0;i<8;i++)
	{
		dist[i] = log(dist[i]);
		Time[i] = log(Time[i]);	
	}

	
	cout<<"	POINT OF ESTIMATION 	ESTIMATED VALUE		ACTUAL VALUE"<<endl;

	df = difftable(Time,dist,8);	
	for(int i=0;i<4;i++)
	{
		cout<<setw(20)<<points[i]<<setw(25)<<exp(interpolate(8,df,Time[0],log(points[i]),dist))<<setw(20)<<actual[i]<<endl;
		
	} 

		df = difftable(dist,Time,8);	
	
	cout<<endl<<"DISTANCE FOR INE HOUR"<<setw(25)<<exp(interpolate(8,df,dist[0],log(3600),Time))<<setw(20)<< 21285<<endl<<endl; 

//float interp(float p , float *fx, float *x,int nop,float a)



return 0;
}
