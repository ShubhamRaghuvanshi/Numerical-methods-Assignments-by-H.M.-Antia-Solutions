#include<iostream>
#include<math.h>
#include<iomanip>
#include"basen.h"


using namespace std;

	number::number(long int b,int d,int p,int signbit)
	{
		base=b;
		dec=d;
		pr=p;	
		ptr = new int[pr];
		overflow=0;
		sign =signbit;
		srand(time(NULL));
	}
		
	number::~number()
	{
		//delete []ptr;	
	}

	void number::getnum()
	{
		for(int i=0;i<pr;i++)
		{
			cout<<"ENTER "<<i+1<<"th digit "<<endl;
			cin>>ptr[i];
			if(ptr[i]>base-1)
			{
				cout<<"THE VALUE IS NOT IN BASE "<<base<<""<<endl;
				i--;
			}		
		}	
	}


	void number::randomnumber()
	{
			
		sign = rand()%2;	
		for(int i=0;i<pr;i++)
		{		
			ptr[i]=rand()%base;
		}
	}


	void number::display()
	{	
		
		if(overflow==0)
		{		
			if(sign==0)
				cout<<"+";
			else 
				cout<<"-";

			for (int i=0;i<pr;i++)
			{
				if (i==dec)
					cout<<" . ";				
				
				cout<<ptr[i];
			
			}cout<<endl;
		}
		else
		{
			cout<<endl<<"OVERFLOW"<<endl;	
			overflow=0;		
		}
		
	}


	number number::complement()
	{
			number c(base,dec,pr,sign);
			for(int i=0;i<pr;i++)
			{	
				c.ptr[i]=(base-1-ptr[i])%base;		
			}
			return c;
			
	}


	number number::addnum(number n,int *carry)
	{
		*carry=0;
		number sum(base,dec,pr,sign);
		for(int i=pr-1;i>=0;i--)
		{	
		
			sum.ptr[i]=ptr[i]+n.ptr[i]+*carry;
			*carry=0;
			if(sum.ptr[i]>base-1)
			{	
				sum.ptr[i]=sum.ptr[i]%(base);
				*carry=1;
			}
		}	
		
		return sum;
	}

	number number::operator + (number n)
	{
		int carry=0;
		int *car = &carry;
			
		number c(base,dec,pr,0),one(base,dec,pr,sign),comp(base,dec,pr,n.sign);
		
				
		one ==1;
		if(sign == n.sign)
		{
			c.sign=sign;
			c =(*this).addnum(n,car);
			if(carry ==1)
				c.overflow=1;			
		}

		else
		{	
			comp=n.complement();
		
	
			c =(*this).addnum(comp,car);
		
			if(carry==1)
			{	*car=0;
				c.sign=sign;
				c=c.addnum(one,car);
			}			
			
			else
			{
				c.sign=n.sign;
				c=c.complement();
			}		
		
		}

		return c;	
	}
	
	number number::operator - (number n)
	{
		n.sign = (n.sign+1)%2;
		return n+*this;
	}


	number number::operator == (int n)
	{	
		int i;
		number c(base,dec,pr,sign);
		c.ptr = ptr;
		
		for (i=pr-1;i>=0;i--)
		{
			c.ptr[i]=n%base;
			n = n/base;
		}

		for(i=0;i<pr;i++)
		{
			if(c.ptr[i]!=0)
			break;
		}	
	//	c.leftshift(i);
			
		return c;
	}


	
	
	void number::leftshift()
	{	
		for(int i=0;i<pr-1;i++)
			(*this).ptr[i]=(*this).ptr[i+1]	;	
		(*this).ptr[pr-1]=0;
		
	}	

	void number::leftshift(int n)
	{
		for (int i=0;i<n;i++)
			(*this).leftshift();
	}

	void number::rightshift(int n)
	{
		for(int i=0;i<n;i++)
			(*this).rightshift();
	}


	void number::rightshift()
	{
		for (int i=pr-1;i>0;i--)
		{
			(*this).ptr[i] = (*this).ptr[i-1];
		}
			(*this).ptr[0]=0;
	}

	int number::operator > (number n)
	{
		int cpr;			
		if(n.pr>pr)
			cpr=n.pr;
		else
			cpr=pr;

		number c(base,dec,cpr,sign);
		
		c = (*this).appendleft(cpr-pr);
		n = n.appendleft(cpr-n.pr);


		for (int i=0;i<cpr;i++)
		{
			if (c.ptr[i]>n.ptr[i])
			{
				return 1;
			}
			else if (c.ptr[i]<n.ptr[i])
			{
				return 0;			
			}				
			else{}
		} 
		return 0;
	}
	
	number number:: divide(int denominator,int precision)
	{
		number d(base,dec,precision,sign),c(base,dec,precision,sign);
		long int a,quotient,remainder;
		int i;
			
			(*this).pr++;
			(*this).rightshift();
			c.dec--;
			
	
			for ( i=0;i<precision;i++)
			{
				 if(i<pr-1)					
					a = base*ptr[i] + ptr[i+1];
				else
					{a = remainder*base;}

				quotient = a/denominator;
				remainder = a - quotient*denominator;
			    ptr[i]=0;
				ptr[i+1] = remainder;
				c.ptr[i]=quotient;	
				d.ptr[i]=quotient;	
				
			}
					
			for( i=0;i<precision;i++)
			{
				if(c.ptr[i]!=0)
				break;
			}
			c.leftshift(i);		
			(*this).pr--;
		return c;
	}

	
	number number::appendleft(int n)
	{
		number c(base,dec,pr+n,sign);	
		for(int i=0;i<pr;i++)
		{
			c.ptr[i] =ptr[i];		
		}
	return c;
	}

	number number::appendright(int n)
	{
		number c(base,dec,pr+n,sign);
		
		for(int i=n;i<n+pr;i++)
		{
			c.ptr[i] = ptr[i-n];
			
		}
		return c;

	}

	number number::multiply(number n,int precision)
	{
		
		int carry=0,flag=0;
		number c(base,dec,2*pr,sign),s(base,dec,2*pr,sign),mult(base,dec,2*pr,sign);
	
		(*this) = (*this).appendright(pr-1);	
			
		for(int i=s.pr-1;i>pr/2;i--)
		{		
			mult = (*this)*n.ptr[i-pr/2-1];		
			mult.leftshift(pr-i);			
			c =mult+s;
			s = c;
		}

		
		
		
		s.pr = precision;
		for(int i=c.pr;i<precision;i++)
			{	
				s.ptr[i]=0;
			}		
		return s;				
	}	
	


  	number number::operator * (int n)
	{
		
		number c(base,dec,pr,sign);
			
		int car=0;
	
		for(int i=pr-1;i>=0;i--)
		{	
			c.ptr[i] = ptr[i]*n+car;
			car=0;
			
			if(c.ptr[i]>base-1)
			{	
				car = c.ptr[i]/base; 		
				c.ptr[i]=c.ptr[i]%base;
			} 
		}
		
		if (car!=0)
		{
			c.pr++;
			c.rightshift();
			c.ptr[0]=car;
		}
					
		return c;	
	   
	}


	number number::arctan()
	{
		int p=10;
		number a0(base,dec,p,sign),a1(base,dec,p,sign),nu(base,dec,p,sign);
	
		a1==0;
		a0=(*this);
		double b0,b1=0,r,x=0;
		b0=x;		

		for(int i=0;i<20;i++)
		{
			r = double(1)/double(2*i+1);
			b1 = pow(-1,2*i+1)*double(pow(x,2*i+1))/double(2*i+1)+b1;	
		
			cout<<b1<<"	"<<r<<"	"<<b0<<endl;
		}

		for(int i=0;i<10;i++)
		{	
		
			a1 = (a0*(2*i+3)).divide(2*i+1,p)+a1;

			a1.display();
			a0.display();
			cout<<endl;
			a0=a1;
			a0.sign = ((i+1)%2);
			
		}
	return a1;
	}

	
	number number::merssene()
	{


	}







