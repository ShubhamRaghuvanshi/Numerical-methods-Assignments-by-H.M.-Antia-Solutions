#include<iostream>

#include"functions.cpp"
using namespace std;

int main()
{
	double x[] = {50,60,70,80,90};
	double y[] = {50,52,54,56,58}, fy[5],part_data[5];
	
	double data[][5] = { {0.9401,0.9647,0.9876,1.0044,1.0107},
						{0.9835,1.0118,1.0387,1.0587,1.0662},
						{1.0277,1.0602,1.0915,1.1152,1.1242},
						{1.0725,1.1097,1.1162,1.1743,1.1851},
						{1.1180,1.1605,1.2030,1.2362,1.2492} }; 	
	
		for(int i=0;i<5;i++)
		fy[i]= interp(65,data[i],x,5,x[0]);
	cout<<"RESULT OF HORZONTAL THEN VERTICAL INTERPOLATION :"<<"	"<<interp(53,fy,y,5,y[0])<<endl;	 
	
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)	
			part_data[j] = data[j][i];
	
		fy[i] =interp(53,part_data,y,5,y[0]);
	}
	cout<<"RESULT OF VERTICAL THEN HORIZONTAL INTERPOLATION :"<<"	"<<interp(65,fy,x,5,x[0])<<endl; 

	for(int i=0;i<5;i++)
		fy[i]= data[i][i];	
	cout<<"RESULT OF DIAGONAL INTERPOLATION :"<<"			"<<interp(53,fy,y,5,y[0])<<endl;

	for(int i=0;i<4;i++)
	  fy[i] = data[i][3-i];

	cout<<"RESULT OF DIAGONAL INTERPOLATION :"<<"			"<<interp(53,fy,y,5,y[0])<<endl;
return 0;
}
