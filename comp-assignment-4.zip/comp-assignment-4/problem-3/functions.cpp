#include<iostream>
#include<iomanip>
#include<math.h>

using namespace std;

    double func1(double n )
    {
        return ( (n+2)/(n*(n+1)*(n*n + 3*n +4) )  );
    }

    double func2(int n )
    {
        return ( 1/double(n));
    }

    double func3(int n)
    {
        return 1.0/double(log(n+1));
    }

    double func41(int n)
    {
        return (-(1.0+n*n)/(n*n+3*n+5));
    }
    double func42(int n)
    {
        return (-(1.0+n*n*0.01)/(n*n+3*n+5));
    }
    double func43(int n)
    {
        return (-(1.0+n*n*1e-6)/(n*n+3*n+5));
    }

    double func5(int n)
    {
        if (n%2==1)
            return (1.0/(2*n-1) +1.0/(2*n+1) );    
        else
            return (-1.0/(n));
    }

    double func6(int n)
    {
        if(n%2==1)
            return 1.0/n;
        else
            return (-1.0/(2*n) - 1.0/(2*n-2));
    }


double euler_maclauren_sum (int ex, double nop, int part)
{
    double B[] = {1.0 , 1.0/6.0 , -1.0/30.0 , 1.0/42.0 , -1.0/30.0 ,5.0/66.0 ,- 691.0/2730.0
                  , 7.0/6.0 , -3617.0/510.0 , 43867.0/798.0 , -174611.0/330.0 };
    int a0;
    double sum = 0;
    a0=ex;

    if(part==4)
    {
        for(int k=1;k<11;k++)
            sum = sum + B[k]*( pow(a0,-2*k) ) /(2*k);
        sum+= 0.5/a0;
    }
    else
    {
        for(int k=1;k<11;k++)
             sum = sum + B[k]*( pow(a0,-2*k) - pow(a0+nop,-2*k) ) /(2*k);
        sum+=( 0.5/a0) + (0.5/(a0+nop));
    }

    for(int i=1;i<a0;i++)
        sum+=(1.0/i);

return (sum- log(a0));

}

double sum (int nop , double(*func)(double) )
{
    double sum =0;
    
    for(int i=1;i<nop;i++)
        sum = sum + func(i);
return sum;

}

double *difftable(double *fx,int nop)
{	
	double *df;
	df = new double[(nop)*(nop-1)];	


	for(int i=0;i<nop;i++)
		for(int j=0;j<nop-i-1;j++)
			if(i==0)
				df[j*(nop-1)+i] = (fx[j+1]-fx[j]);
			else
				df[j*(nop-1)+i] = (df[(j+1)*(nop-1)+i-1] -df[j*(nop-1)+i-1]); 

	
	return df;
}



double euler_transform_sum( double(*func)(int) , int nop , int p,double initial_point)
{
    double  *df ,sum=0,factor;
    int s=1;
          
    double f[nop] , x[nop];
     
    for(int i=1;i<p;i++)
    {
        sum = sum + s*func(i+initial_point);
        s = -s;
    }   
      
    for (int i=p+1;i<p+nop+1;i++)
        f[i-1-p] = s*func(i-1+ initial_point );
               
    df = difftable(f,nop);
    s = -1;
    sum = sum + f[0]/2.0;
    factor=4;
    
    for(int i=0;i<nop-1;i++)
    {
        sum = sum + s*df[0*(nop-1)+ i]/double(factor);
        factor = 2*factor;
        s = -s;
    }
    return sum;
}























