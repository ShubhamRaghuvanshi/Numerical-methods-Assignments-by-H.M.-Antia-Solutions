#include<iostream>
#include<iomanip>
#include<math.h>
using namespace std;




void display( double *m,int dimr,int dimc)
{
  cout.precision(7);
  for(int i=0;i<dimr;i++)
  {
    for(int j=0;j<dimc;j++)
	{
      cout<<setw(15)<<*(m+dimc*i+j);
    }cout<<endl;
  }cout<<endl;
}

//**************************************************************************

void showvector(double *m,int dim)
{
  for(int i=0;i<dim;i++)
  {
    cout<<*(m+i)<<endl;
  }cout<<endl;
}

//***************************************************************************

double *forward_substitution( double *a,double *b,int dim)
{
  double sum=0;
  double *x;
  x = new double[dim];

  for(int i=0;i<dim;i++)
  { 
    sum =0;
    for(int j=0;j<i;j++)
    {
        sum = *(a+dim*i+j)*x[j]+sum;
    }
    x[i] = (*(b+i)-sum)/(*(a+dim*i+i));
  }
 return x;
}

//****************************************************************************

double *backward_substitution( double *a,double *b,int dim)
{
  double sum=0;
  double *x;
  x = new double[dim];

  for(int i=dim-1;i>=0;i--)
  { 
    sum =0;
    for(int j=dim-1;j>=i;j--)
    {
        sum = *(a+dim*i+j)*x[j]+sum;
    }
    x[i] = (*(b+i)-sum)/(*(a+dim*i+i));
  }
 return x;
}

//*************************************************************************

double  *gauss(double *a,int r,int c)
{
  double temp;
  
  double *x,sum;
  x = new double[r];

  for(int k=0;k<r;k++)
  {
    for(int i=k+1;i<r;i++)
    {
      temp = (*(a+i*c+k));
    
      for(int j=0;j<c;j++)
      {
        *(a+i*c+j) = *(a+i*c+j) - temp*(*(a+k*c+j))/(*(a+k*c+k)); 
      }
    }
  }
  
  for(int i=r-1;i>=0;i--)
  { sum=0;
    for(int j=r-1;j>=i;j--)
    {
        sum = *(a+c*i+j)*x[j] +sum ;
   }  
    x[i] = (*(a+c*i +r)-sum)/(*(a+c*i+i));
 
  } 
  return x;
}

//***********************************************************************

double fibonacci(int n)
{
  double f2,f1=1,f0=0;
	
  if(n==0)
    return 0;
  if(n==1)
    return 1;
  
	for(int i=2;i<=n;i++)
	{
      f2 =f1+f0;
	  f0=f1;
      f1=f2;
    }
  return f2; 
}

//**********************************************************************

































