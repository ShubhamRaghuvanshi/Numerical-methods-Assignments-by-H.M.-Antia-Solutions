#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"
using namespace std;

int main()
{
    cout.precision(15);
    long double a = pow(10,pow(10,10));
   double ex[] = {200,12495,pow(2,44),pow(10,100),1},sum;

       cout<<" SUMMATION 1/I  "<<setw(50)<<" NUMBER OF POINTS"<<endl<<endl;
    for(int i=0;i<4;i++)
    {
         sum  =  euler_maclauren_sum(200,ex[i],i+1)  ;  
        cout<< (sum +  log(ex[i])) <<setw(50)<<ex[i]<<endl;
cout<<endl;
    }
       cout<< sum + pow(10,100)*log(10)<<setw(50)<<"10^(10^10)"<<endl<<endl;

    cout<<" EULER CONSTANT  "<<setw(50)<<" NUMBER OF POINTS"<<endl<<endl;
for(int i=0;i<5;i++)
    cout<<  euler_maclauren_sum(200,ex[i],i+1) <<setw(50)<<ex[i]<<endl;
cout<<endl;
 
   return 0;   
}

