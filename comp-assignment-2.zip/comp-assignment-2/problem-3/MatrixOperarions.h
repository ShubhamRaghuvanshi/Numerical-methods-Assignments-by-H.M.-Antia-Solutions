#ifndef MATRIXOPERATIONS_H
#define MATRIXOPERATIONS_H
 
class matrix
{
	private:
		int maxrow,maxcol;
		double *ptr;
	
	public:
		matrix(int r,int c);
		matrix(int r);
		
		void setcomp(int i,int j,double value);
		void display();
		
		
		matrix operator*(matrix b);
		
		matrix transpose();
		void identitymatrix(int r,int c);
	
		double* getpointer();
		matrix gibbins(int row1,int row2,double c,double s);
		
		double getcomp(int row,int col);
		matrix getcolumn(int col); 
		matrix eigen(matrix A , int order,int flag);
		void svd(matrix A,matrix U,matrix sigmasq,matrix V,matrix b);
		
};
		
		
		
#endif


