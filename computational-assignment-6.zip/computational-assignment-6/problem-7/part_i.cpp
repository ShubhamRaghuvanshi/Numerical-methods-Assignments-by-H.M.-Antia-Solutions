#include<iostream>
#include<iomanip>
#include<fstream>
#include"functions.cpp"

using namespace std;

int main()
{
    cout.precision(15); 
    int N=400,i=0,n[]={N,N-1}; 
    double w[N][N] ={0},l,u,temp,guess[N],m;
    double xi=0,xf=1, h = (xf-xi)/double(N); 
        
    ofstream data1, data2;      // DATA IS WRITTEN IN THESE FILES
    data1.open("part11.txt");
    data2.open("part12.txt");

    initialize(*w,h,xi+h,xf-h,N,1);  // INITIALIZE THE OPERATOR MATRIX

 
 // gerchgoren theorem for finding the limits on the eigenvalue
   
    l = w[i][i] -abs( w[i+1][i] );
    u = w[i][i] +abs( w[i+1][i] );
    for( i=1;i<N;i++)
    {     
        if (i==N-1)
            temp = abs( w[i][i-1] ) ;
        else
             temp =abs( w[i][i-1] )+ abs( w[i+1][i] );
        if(l> w[i][i]-temp)
        l=w[i][i]-temp;  
        if(u<w[i][i]+temp)
        {u =w[i][i]+ temp;}
    }
    cout<<"EIGEN VALUES LIE IN THE RANGE {"<<l<<" , "<<u<<" }"<<endl<<endl;
 
    h  = (1.0 - 2.0/N)/(N-1) ;

    data1<<0<<" "<<0.0<<endl;
    
    data2<<0<<" "<<0.0<<endl;
   
//
for(int i=0;i<2;i++)
{
    xi = h;
    sturm(*w,N,l,u,guess,n[i],m,1e-15);
    cout<<n[i]<<"th EIGENVALUE IS :"<<setw(30)<<m<<endl;
    cout<<endl<<"THE CORRESPONDING EIGENVECTOR IS WRITTEN IN THE FILE AND PLOT IS GIVEN :"<<endl;   
    for(int j=0;j<N;j++)
    {
       if(i==0) data1<<xi<<" "<<guess[j]<<endl;
       if(i==1) data2<<xi<<" "<<guess[j]<<endl;
       xi = xi+h; 
    } 
    cout<<endl<<"***************************************************"<<endl;
  
}
       data1<<1<<" "<<0.0<<endl;
        data2<<1<<" "<<0.0<<endl;

    data1.close();
    data2.close();


    return 0;
}
