#include<iostream>

using namespace std;

float *difftable(float *fx, float *x,int nop)
{	
	float *df;
	df = new float[(nop)*(nop-1)];	
	for(int i=0;i<nop;i++)
		for(int j=0;j<nop-i-1;j++)
			if(i==0)
				df[j*(nop-1)+i] = (fx[j+1]-fx[j])/(x[j+1]-x[j]);
			else
				df[j*(nop-1)+i] = (df[(j+1)*(nop-1)+i-1] -df[j*(nop-1)+i-1])/(x[j+1+i]-x[j]); 
	return df;
}

float interpolate(int nop , float *df, float fx0,float p ,float *x)
{
	float fox = fx0,product=1;
	
	for(int i=0;i<nop-1;i++)
	{
		product = product*(p - x[i]);		
		fox = fox + product*df[0*(nop-1)+ i];
	}
	return fox;
} 
