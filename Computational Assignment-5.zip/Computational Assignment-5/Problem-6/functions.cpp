#include<iostream>
#include<math.h>
#include<iomanip>

using namespace std;
    
double func1(double *x )
{
     return  { 2*x[0]*x[0]*x[0] - 3*x[0]*x[0] -6*x[0]*x[1]*(x[0]-x[1]-1)};
}

void gradfunc1(double *x, double *grad)
{
    grad[0] = 6*(  x[0]*(x[0]-2*x[1]-1) + x[1]*(x[1]+1) );
    grad[1] =  6*x[0]*(1+2*x[1]-x[0]);   
}

double func2(double *x)
{
    double tempf1,f;
    tempf1 = x[1]-x[0]*x[0];
    f = 100*tempf1*tempf1; 
     tempf1 = 1 -x[0];
    f = f -tempf1*tempf1;
    tempf1 = x[3] - x[2]*x[2];
    f = f+90*tempf1*tempf1;   
    tempf1 = 1 -x[2];
    f = f+tempf1*tempf1;
    tempf1 = (x[1]-1)*(x[1]-1) + (x[3]-1)*(x[3]-1);
    f = f +10.1*tempf1;
    tempf1 = (x[1]-1)*(x[3]-1);       
    f = f+19.8*tempf1;
	 
	return f;
}

void gradfunc2(double *x , double *grad)
{
    grad[0] = 2 + 400*x[0]*x[0]*x[0] -2*x[0]*(1+200*x[1]);
    grad[1] = -40 - 200*x[0]*x[0] + 220.2*x[1] +19.8*x[3];
    grad[2] = 2*( -1 +x[2] +180*x[2]*x[2]*x[2]-180*x[2]*x[3]  );
    grad[3] = -40 +19.8*x[1] - 180*x[2]*x[2]*x[2]+200.2*x[3];  
}

double func2a(double a,double *x,double *s )
{
    double y[4];
    for(int i=0;i<4;i++)
        y[i] = x[i] - a*s[i];
    return func2(y);
}

double func1a(double a,double *x,double *s )
{
    double y[4];
    for(int i=0;i<4;i++)
        y[i] = x[i] - a*s[i];
    return func1(y);
}


double bracket( double func(double ,double * ,double *) ,double *x, double *s ,double a, double c,double acc)
{
    double b,d,fa,fb,fc,fd,t;
    int i;   
 
    t = (3-sqrt(5))/2;
    for(i=0;i<10000;i++)
    {
        b=a+(c-a)*t;
        d=c-(c-a)*t;
        if(abs(b-d)<acc) break;
        fa = func(a,x,s);
        fb = func(b,x,s); 
        fc = func(c,x,s);
        fd = func(d,x,s);     
        
        if(fd<fb)
            a=b;
        else
            c=d;
    }
return b;
}

double steepestdecent(double (*func)(double *) , double *x, int niter , double aeps ,int N)
{
    double alpha=1, grad[N] , y[N];
    int m;
    for(int i=0;i<niter;i++)
    {
        m=0;
             gradfunc1(x,grad); 
        for(m=0;m<N;m++)
        {
            if (abs(grad[m])>aeps)
            break;
        }  
        if(m==N||abs(alpha)<10*aeps)  break;
          
            alpha  = bracket(func1a,x,grad,0,1,aeps);
        for(int k=0;k<N;k++)
            
            x[k] = x[k] - alpha*grad[k]; 
                           
             
    }    
   
    return func(x);   
}














