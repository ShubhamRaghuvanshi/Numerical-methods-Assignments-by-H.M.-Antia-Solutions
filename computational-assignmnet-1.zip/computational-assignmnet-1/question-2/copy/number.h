class number
{	
	private:
		int dec,pr,*ptr,overflow,sign;
	 int base;
	public:
		 number(int b,int d,int p,int signbit);
		~number();
		void getnum();
		void display();
		void randomnumber();
};
