#include<iostream>
#include<math.h>
#include"function.cpp"
#define pi 3.14159
using namespace std;

int main()
{
  int n[] = {5,10,15};

cout<<"START part a"<<endl;
for(int k=0;k<3;k++)
{
  long double a[n[k]][2*n[k]+1],b[n[k]],acopy[n[k]][n[k]];
  long double x[n[k]], identity[n[k]][n[k]],product[n[k]][n[k]];

  for(int i=0;i<n[k];i++)
  { 
    a[i][2*n[k]]=0;
    x[i]=0;
  }

  for(int i=0;i<n[k];i++)
    for(int j=0;j<n[k];j++)
     {
       product[i][j]=0;
       if(i==j)
         identity[i][j]=1;
       else
         identity[i][j]=0; 
    }
  


  for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      a[i][j] = 1.0/(long double)(i+j+1);
      acopy[i][j] = a[i][j];
	  a[i][j+n[k]]=0;
      if(i==j)
        {
          a[i][j+n[k]]=1;
        }
      a[i][2*n[k]] = a[i][2*n[k]] + a[i][j];
   }
      b[i] = a[i][2*n[k]];
  }

  cout<<"FOR THE MATRIX FOR n = "<<n[k]<<" IS :"<<endl;
  **a = *inverse (*a,n[k],2*n[k]+1);
  cout<<"INVERSE IS:"<<endl;
  display(*a,n[k],2*n[k]+1,n[k],2*n[k]);
  cout<<"THE SOLUTION OF THE GIVEN SYSEM OF EQUATION BY GAUSS JORDAN IS :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;
  display(*a,n[k],2*n[k]+1,2*n[k],2*n[k]+1);

  cout<<"SOLUTION USING A^(-1)*B is :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;

  for(int j=0;j<n[k];j++)
  {
   for(int i=0;i<n[k];i++)
   {
     x[j] = x[j] + a[j][i+n[k]]*b[i]; 
   }
   cout<<"		"<<x[j]<<endl;
  } 
 
   for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      for(int s=0;s<n[k];s++)
      {
        product[i][j] = a[i][s+n[k]]*acopy[s][j] + product[i][j];   
      } 
       product[i][j] = product[i][j] - identity[i][j];;
    }
  }

  cout<<"A*A^(-1)-I IS:"<<endl<<endl; 
  display(*product,n[k],n[k],0,n[k]);
  

cout<<"**********************************************************************";
cout<<"***********************************************************"<<endl<<endl;
} cout<<"END PART a"<<endl;
  cout<<"####################################################################";
  cout<<"#########################################################"<<endl<<endl;
//******************************************************************************

cout<<"START part b"<<endl;
for(int k=0;k<3;k++)
{
  long double a[n[k]][2*n[k]+1],b[n[k]],acopy[n[k]][n[k]];
  long double x[n[k]], identity[n[k]][n[k]],product[n[k]][n[k]]; 

  for(int i=0;i<n[k];i++)
  { 
    a[i][2*n[k]]=0;
    x[i]=0;
  }

  for(int i=0;i<n[k];i++)
    for(int j=0;j<n[k];j++)
     {
       product[i][j]=0;
       if(i==j)
         identity[i][j]=1;
       else
         identity[i][j]=0; 
     }
  

  for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      a[i][j] = sqrt(2.0/(long double)(n[k]+1)) * sin( (i+1)*(j+1)*pi/((long double )(n[k]+1)));
	  acopy[i][j]=a[i][j];
      a[i][j+n[k]]=0;
      if(i==j)
        {
          a[i][j+n[k]]=1;
        }
      a[i][2*n[k]] = a[i][2*n[k]] + a[i][j];
   }
      b[i] = a[i][2*n[k]];
  }
//  display(*a,n[k],2*n[k]+1,0,2*n[k]+1);
  
  cout<<"FOR THE MATRIX FOR n = "<<n[k]<<" IS :"<<endl;
  **a = *inverse (*a,n[k],2*n[k]+1);
  cout<<"INVERSE IS:"<<endl;
  display(*a,n[k],2*n[k]+1,n[k],2*n[k]);
  cout<<"THE SOLUTION OF THE GIVEN SYSEM OF EQUATION BY GAUSS JORDAN IS :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;
  display(*a,n[k],2*n[k]+1,2*n[k],2*n[k]+1);

  cout<<"SOLUTION USING A^(-1)*B is :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;

  for(int j=0;j<n[k];j++)
  {
   for(int i=0;i<n[k];i++)
   {
     x[j] = x[j] + a[j][i+n[k]]*b[i]; 
   }
   cout<<"		"<<x[j]<<endl;
  } 
 
  for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      for(int s=0;s<n[k];s++)
      {
        product[i][j] = a[i][s+n[k]]*acopy[s][j] + product[i][j];   
      } 
       product[i][j] = product[i][j] - identity[i][j];;
    }
  }

  cout<<"A*A^(-1)-I IS:"<<endl<<endl; 
  display(*product,n[k],n[k],0,n[k]);

cout<<"**********************************************************************";
cout<<"***********************************************************"<<endl<<endl;
} cout<<"END PART b"<<endl;
  cout<<"####################################################################";
  cout<<"#########################################################"<<endl<<endl;

//******************************************************************************

cout<<"START part c"<<endl;
for(int k=0;k<3;k++)
{
  long double a[n[k]][2*n[k]+1],b[n[k]],acopy[n[k]][n[k]];
  long double x[n[k]], identity[n[k]][n[k]],product[n[k]][n[k]]; 

  for(int i=0;i<n[k];i++)
  { 
    a[i][2*n[k]]=0;
    x[i]=0;
  }

  for(int i=0;i<n[k];i++)
    for(int j=0;j<n[k];j++)
     {
       product[i][j]=0;
       if(i==j)
         identity[i][j]=1;
       else
         identity[i][j]=0; 
    }
  

  for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      a[i][j] = (long double) (n[k]+1-max(i+1,j+1));
      acopy[i][j] = a[i][j];
	  a[i][j+n[k]]=0;
      if(i==j)
        {
          a[i][j+n[k]]=1;
        }
      a[i][2*n[k]] = a[i][2*n[k]] + a[i][j];
   }
      b[i] = a[i][2*n[k]];
  }
//  display(*a,n[k],2*n[k]+1,0,2*n[k]+1);
  
  cout<<"FOR THE MATRIX FOR n = "<<n[k]<<" IS :"<<endl;
  **a = *inverse (*a,n[k],2*n[k]+1);
  cout<<"INVERSE IS:"<<endl;
  display(*a,n[k],2*n[k]+1,n[k],2*n[k]);
  
  cout<<"THE SOLUTION OF THE GIVEN SYSEM OF EQUATION BY GAUSS JORDAN IS :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;
  display(*a,n[k],2*n[k]+1,2*n[k],2*n[k]+1);

  cout<<"SOLUTION USING A^(-1)*B is :";
  cout<<"(from x0 to x"<<n[k]<<")"<<endl;

  for(int j=0;j<n[k];j++)
  {
   for(int i=0;i<n[k];i++)
   {
     x[j] = x[j] + a[j][i+n[k]]*b[i]; 
   }
   cout<<"		"<<x[j]<<endl;
  }  

  for(int i=0;i<n[k];i++)
  {
    for(int j=0;j<n[k];j++)
    {
      for(int s=0;s<n[k];s++)
      {
        product[i][j] = a[i][s+n[k]]*acopy[s][j] + product[i][j];   
      } 
       product[i][j] = product[i][j] - identity[i][j];;
    }
  }

  cout<<"A*A^(-1)-I IS:"<<endl<<endl; 
  display(*product,n[k],n[k],0,n[k]);

cout<<"**********************************************************************";
cout<<"***********************************************************"<<endl<<endl;
} cout<<"END PART c"<<endl;
  cout<<"####################################################################";
  cout<<"#########################################################"<<endl<<endl;








return 0;
}
