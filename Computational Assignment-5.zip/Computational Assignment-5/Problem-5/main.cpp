#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"
using namespace std;



int main(){
  cout.precision(7);
  double a[]={10,20,20.3959}, h[3]={1,1,0.001};
  int temp;

 
 

    cout<<"******************************************************************************"<<endl;
    cout<<"PART A"<<endl;
    for(int i=0;i<3;i++)
    {
        cout<<endl<<"FOR a = "<<a[i]<<""<<endl;
        cout<<"-------------------------------"<<endl;
        goldensearch(func1,a[i],-30,30,64,1e-300);    
    }

    cout<<"*****************************************************************************"<<endl;
    cout<<"PART B"<<endl;
    goldensearch(func2,a[0],0,30,64,1e-300); 

    cout<<"*****************************************************************************"<<endl;
    cout<<"PART C"<<endl;
    goldensearch(func3,a[0],0,30,64,1e-300); 
   
    cout<<"*****************************************************************************"<<endl;
    cout<<"PART C"<<endl;
    goldensearch(func4,a[0],0,2,2*4096,1e-300); 

    

return 0;
}

