#include<iostream>
#include<iomanip>
#include<math.h>
using namespace std;




void display(long double *m,int dimr,int dimc,int offset,int en)
{
  cout.precision(5);
  for(int i=0;i<dimr;i++)
  {
    for(int j=offset;j<en;j++)
	{
      cout<<setw(14)<<*(m+dimc*i+j);
    }cout<<endl<<endl;
  }cout<<endl;
}



//**********************************************************************

long double *inverse(long double *a,int r,int c)
{
 long double temp;
  for(int k=0;k<r;k++)
  {

    for(int i=k+1;i<r;i++)
    {
      temp = (*(a+i*c+k));
      for(int j=0;j<c;j++)
      {
        *(a+i*c+j) = *(a+i*c+j) - temp*(*(a+k*c+j))/(*(a+k*c+k)); 
      }
    }
  }

 for(int k=r-1;k>=0;k--)
  {

  
    for(int i=k-1;i>=0;i--)
    {
      temp = (*(a+i*c+k));
      for(int j=0;j<c;j++)
      {
        *(a+i*c+j) = *(a+i*c+j) - temp*(*(a+k*c+j))/(*(a+k*c+k)); 
      }
    }
  }

  temp=1;
  for(int i=0;i<r;i++)
  {
    temp = *(a+i*c+i)*temp;
  }
  
  cout<<endl<<"DETERMINANT IS :"<<temp<<endl<<endl;   

  for(int i=0;i<r;i++)
  {   

    for(int j=0;j<c/2+1;j++)
    {
       *(a+i*c+j+c/2) = (*(a+i*c+j+c/2))/ (*(a+i*c+i)) ;
    } 
  
  }


return a;
}


//*************************************************************************

int max(int i,int j)
{
  if(i>j)
    return i;
  else 
    return j;
}
























