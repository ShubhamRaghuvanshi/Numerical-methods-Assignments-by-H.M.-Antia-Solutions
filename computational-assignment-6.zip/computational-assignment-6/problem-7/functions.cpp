#include<iostream>
#include<iomanip>
#include<math.h>

using namespace std;


// TO INITIALIZE THE MATRICES
void initialize(double *w, double h, double xi,double xf, int n, int q)
{
    switch (q)
    {
        case 1: 
        {   cout<<"here"<<endl;
            for(int i=0;i<n;i++)
                 w[i*n+i]=2.0*(n+1)*(n+1);    
            for(int i=0;i<n-1;i++)      
            {
                w[i*n+i+1]  = -1.0*(n+1)*(n+1);
                w[(i+1)*n+i]= -1.0*(n+1)*(n+1);
	        }
        break;
        }
    
        case 2:        
        { 
            for(int i=0;i<n;i++)
                { 
                   w[i*n+i]= 2.0/(h*h)+ xi*xi;  
                   xi = xi+h;                  
                }
            for(int i=0;i<n-1;i++)      
            {
                w[i*n+i+1]= -1.0/(h*h);
                w[(i+1)*n+i]=w[i*n+i+1];
	        }
         break;
        }
    }
}

void print (double *m , int N)
{
    for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
            cout<<setw(23)<<m[i*N+j];    		
        }   cout<<endl;
    }    
}

//BACK SUBSTITUTION REQUIRED FOR GAUSS ELEMINATION 
double* backwardsub(double **mat,double *matb,int N){
    
  double *sol;
  sol = new double [N];
  for(int i=0;i<N;i++)
    sol[i] = 0;
  for(int i=N-1;i>=0;i--){
    double rhs=0;
    for(int j=N-1;j>i;j--){
      rhs+=mat[i][j]*sol[j];
    }
    sol[i] = (matb[i]-rhs)/mat[i][i];
  }

  return sol;
}

//GAUSS ELIMINATION WITH MATRIX A
// RETURNS THE POINTER OF THE SOLUTION
double *gausselimination(double *a,double *k,int N) {
  double **mat,*matb;
  matb = new double [N];
  mat = new double *[N];
  for(int i=0;i<N;i++)
    mat[i] = new double [N];
  for(int i=0;i<N;i++){
    for(int j=0;j<N;j++)
      mat[i][j]=a[i*N+j];
    matb[i]=k[i];
  }
  
    double *sol;
    sol = new double [N];
    for(int i=0;i<N;i++){
    //pivoting code begins
    double temp;
    int tempi;
    temp=mat[i][i];
    tempi=i;
    for(int j=N-1;j>=i;j--){
       if(abs(mat[j][i]) > abs(temp)){
          tempi=j;
          temp = mat[j][i];
      }
    }
    for(int k=0;k<N;k++){
      swap(mat[tempi][k],mat[i][k]);
    }
    swap(matb[tempi],matb[i]);
       for(int j=N-1;j>i;j--){
      double factor;
      factor=mat[j][i]/mat[i][i];
      for(int k=0;k<N;k++){
        mat[j][k] -= mat[i][k]*factor;
      }
      matb[j]-=matb[i]*factor;
    }
    
     }
     sol = backwardsub(mat,matb,N);
    
   for(int l=N-1;l>=0;l--){
    delete [] mat[l];
  }
  delete []mat;
  delete []matb;
  
  return sol;
}




//TO get NUMBER OF SIGN CHANGES REQUIRED FOR STURM SEQUENCE METHOD
int v(double l,int N, double *w,double &p, int &fcall)
{
    double q,spq=1e-6;
    int roots=0;
    fcall++;
    q = l - w[0];
    p=q;
    if (q<0) roots=1;    
    for(int i=1;i<N;i++)
    {   
        if(q!=0) q = l - w[i*N+i] - w[i*N +i-1]*w[i*N+i-1]/q;
        else q = l-w[i*N+i] - w[i*N +i-1]*w[i*N+i-1]/spq;
        if(q<0) roots++;
        p = q*p; 
   }  
return roots;
}

//CODE FOR INVERSE ITERATION
//p = INITAL GUESS AND EIGEN VALUE
// U = EIGEN VECTOR IS WRITTEN IN U
void invit(double *a , double &p ,double *u ,int N)
{
    double *v,temp=1,norm1=0,norm2=0 ,b[N][N],tempp ;

    for(int itr=0;itr<20;itr++)
    { 
        norm1=0;norm2=0;
        tempp=p;
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                if(i==j)
                    b[i][j] = a[i*N+j]-p;
                else 
                    b[i][j] = a[i*N+j];
            }
        }    
        v = gausselimination(*b,u,N); 
        temp = v[0];
        for(int i=1;i<N;i++)
        {   
            if(temp<v[i])
                temp = v[i];
        }
           
    for(int t=0;t<N;t++)
    {
        norm1  = norm1 + v[t]*u[t];
        norm2 = norm2 + v[t]*v[t];            
    }

     p = p + norm1/norm2; 
  
       for(int i=0;i<N;i++)
            u[i] = v[i]/temp;          
        if(abs(tempp-p)<1e-13|| abs(norm2)>1e20) break; 
   }       
}

//STURM SEQUENCE METHOD
// (l ,u)= interval for eigen values
// m = EIGEN VALUE IS WRITTEN IN m
// W = MAtrix
// guess = GUESS EIGEN VECTOR 
void sturm(double *w , int N ,double l,double u,double *guess ,int k,double &m,double aeps)
{
    double vl=0,vu=0,pl,pu,pm,h,temp;
    int i=0,fcall=0;
     h = (u-l)/N;

    for(i=0;i<5000;i++)
    {   
        vu =v(u,N,w,pl,fcall); 
        if (vu ==k-1) break;
        else if (vu>k-1)
        
        { u = u+h; h=h/4; }
        u = u-h;       

   }
      h = (u-l)/N;
    for( i=0;i<5000;i++)
    {   
        vl =v(l,N,w,pl,fcall);
        if(vl ==k ) break;
        else if  (vl<k)
        {  l= l-h; h=h/4;     }
        l = l+h;       
    } 
    for(i=0;i<1000;i++)     //BISECTION FOR ZEROING IN TO EIGEN VALUE
    {
        m = (l+u)/2;
        v(l,N,w,pl,fcall);  v(u,N,w,pu,fcall); v(m,N,w,pm,fcall);
        if(abs(u-l)<aeps)          {break;}
        else if(abs(pl)<aeps)      {m=l;break;}
        else if(abs(pu)<aeps)      {m=u;break;}
        else if(abs(pm)<aeps)      {break;}
        else if(pl*pm>0)            l = (l+u)/2;
        else if(pm*pu>0)            u = (l+u)/2;
    }
    for(int i=0;i<N;i++)
        guess[i]=double(rand())/double(RAND_MAX);
    invit(w,m, guess ,N ); // INVERSE ITERATION WRITES 

}




