#include<iostream>
#include<math.h>
using namespace std;

long double summ(long double m )
{
	
	long double sum=0,i;
	for( i=1;i<=m;i=i+1)
	{
		sum = sum + (1/i);
	}
return sum;
}



int main()
{
	cout.precision(10);
	long double x,func1,func2;
	int factor,count=0,maxcount=100;
	factor=10;

//PART i
	func1=10;
	func2=1;
	cout<<"PART i"<<endl;

	for(x=0.1;abs(func1-func2)>0;x=x/factor)
	{	count++;
		func1 = sin(factor*x)/(factor*x);
		func2 = sin(x)/x;
		if(count>=maxcount)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;			
			break;		
		}
	}
	cout<<"*******************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END

//PART ii
		func1 =2*func2;	
		count=0;		
		cout<<"PART ii"<<endl;
	for(x=pow(10,5);abs(func1-func2)>0;x=x/factor)
	{	count++;
		func1 = (x*factor)*log(x*factor);
		func2 = x*log(x);
		if(count>=1000)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;			
			break;
		}
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END


//PART iii
		func1 =2*func2;	
		count=0;		
		cout<<"PART iii"<<endl;
	for(x=pow(10,1);abs(func1-func2)>0;x=x*factor)
	{	count++;
		func1 = log(x*factor)/pow(x*factor,0.01);
		func2 = log(x)/pow(x,0.01);

		if(count>=1000)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END
	


//PART iv
		func1 =2*func2;	
		count=0;		
		cout<<"PART iv"<<endl;
	for(x=pow(10,1);abs(func1-func2)>0;x=x/factor)
	{	count++;
		func1 = (exp(x*factor)-1)/(x*factor);
		func2 = (exp(x)-1)/x;
		if(count>=1000)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END
	

//PART v
		func1 =1;
		func2=10;	
		count=0;		
		cout<<"PART v"<<endl;
	for(x=0.1;abs(func1-func2)>0.000000001;x=x/factor)
	{	count++;
		func1 =	(sin(factor*x)-sinh(factor*x))/(x*x*x*factor*factor*factor);
		func2 =	(sin(x)-sinh(x))/(x*x*x);
		if(count>=maxcount)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END
	


//PART vi
		func1 =1;
		func2=10;
		count=0;		
		cout<<"PART vi"<<endl;
	for(x=0.1;abs(func1-func2)>0;x=x/factor)
	{	count++;
		func1 =	(sin(factor*x)+sinh(factor*x)-2*x*factor)/pow(x*factor,5);
		func2 =	(sin(x)+sinh(x)-2*x)/(x*x*x*x*x);
		if(count>=maxcount)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END


//PART vii
		func2=10;
		func1 =2*func2;	
		count=0;		
		cout<<"PART vii"<<endl;
	for(x=0;count<20;x=x+0.0000001)
	{	count++;
		
		func1 =	-log(x+0.000001)/factor;
		func2 = log(x)/(1-x);
		factor=factor/10;
		if(count>=maxcount)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END



//PART viii
		func2=10;
		func1 =2*func2;	
		factor=10;		
		count=0;	
		
		cout<<"PART viii	"<<endl;
	for(x=1;abs(func1-func2)>0.000000001;x=x*factor)
	{	count++;
		
		func1 =	pow((1+1/(factor*x)),factor*x)-exp(1);
		func2 = pow( (1+1/x),x)-exp(1);
	
		if(count>=maxcount)
		{	
			cout<<"DOESNT CONVERGE MORE"<<endl;
			break;
		}
	
	}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func2<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END



//part ix			
		cout<<"PART ix	"<<endl;
		func2=10;
		func1=1;		
		count=0;
		for(long double i=10000;abs(func1-func2)>0.00000001;i=i*10)
			{	count++;
				func1=summ(i)-log(i);
				func2=summ(10*i)-log(10*i);
				
				if(count>6)
				break;
			}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func1<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END




//part x		
		cout<<"part x"<<endl;
		count=0;
		for(x=pow(10,-100);abs(func1-func2)>0;x=x/10)
			{
				count++;
				func1 = pow(x*10,0.01)*log(x*10);
				func2 = pow(x,0.01)*log(x);	
				if(count>4500)
				{
					cout<<"DID'nt CONVERGE"<<endl;
					break;
				}
	
			}
			cout<<"*********************************************"<<endl;
			cout<<"LIMIT = "<<func1<<"	FOR X = 	"<<x<<endl;
			cout<<endl<<"**************************************"<<endl<<endl;

//END




//part xi			
		cout<<"PART xi	"<<endl;
		func2=10;
		func1=1;		
		count=0;
		for(x=1;abs(func1-func2)>0.00000001;x=x*factor)
			{	count++;
				func1= x*factor*sqrt(1+x*x*factor*factor)-x*x*factor*factor;
				func2= x*sqrt(1+x*x)-x*x;
				if(count>20)
				break;
			}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func1<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END


//part xii			
		cout<<"PART xii	"<<endl;
		func2=10;
		func1=1;		
		count=0;
		for(x=1;abs(func1-func2)>0.00000001;x=x*factor)
			{	count++;
				func1= cosh(x*factor)/sinh(x*factor);
				func2= cosh(x)/sinh(x);
				if(count>20)
				break;
			}
	cout<<"*********************************************"<<endl;
	cout<<"LIMIT = "<<func1<<"	FOR X = 	"<<x<<endl;
	cout<<endl<<"**************************************"<<endl<<endl;
//END












		


}	
