#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"
using namespace std;

int main()
{
    cout.precision(15);
    int nop , interp=32; 
    double infinite_sum;

    //sum s1
         cout<<"SUM 1"<<endl;
         nop = 524288;
         cout<<"ACTUAL VALUE OF THE SUM:     "<<0.436827337720<<endl<<endl; 
         cout<<"CALCULATED VALUE:            "<<1 - 2*sum (nop, func1)<<endl; 
         cout<<"********************************************************"<<endl;

    //sum s2
        cout<<"SUM 2"<<endl;
        cout<<"ACTUAL VALUE OF THE SUM:     "<<log(2)<<endl<<endl; 
        nop = 65;
        cout<<"CALCULATED VALUE:            "<< euler_transform_sum(func2,interp,nop,0)<<endl<<endl;
        cout<<"********************************************************"<<endl;

    //sum s3
     
        cout<<"SUM 3"<<endl;
        cout<<"ACTUAL VALUE OF THE SUM:    "<<0.924299897223<<endl<<endl; 
        cout<<"CALCULATED VALUE:           "<<euler_transform_sum(func3,interp,nop,0)<<endl<<endl;
        cout<<"********************************************************"<<endl;

    //sum s4

        cout<<"SUM 4"<<endl;
  
        cout<<setw(35)<<" N = INFINITY"<<setw(30)<<"N = 1000"<<setw(30)<<"N = 10^9"<<endl<<endl;

        cout<< " APLHA = 1"<<setw(30);
        infinite_sum = euler_transform_sum(func41,interp,nop,0);
        cout<<infinite_sum<<setw(30);
        cout<< infinite_sum - euler_transform_sum(func41,interp,1,1000)<<setw(30);
        cout<< infinite_sum - euler_transform_sum(func41,interp,1,pow(10,9));
        cout<<endl;
        
        cout<< " APLHA = 0.01"<<setw(27);
        infinite_sum = euler_transform_sum(func42,interp,nop,0);
        cout<<infinite_sum<<setw(31);
        cout<< infinite_sum - euler_transform_sum(func42,interp,1,1000)<<setw(30);
        cout<< infinite_sum - euler_transform_sum(func42,interp,1,pow(10,9));
        cout<<endl;
        
        cout<< " APLHA = 1e-6"<<setw(26);
        infinite_sum = euler_transform_sum(func43,interp,nop,0);
        cout<<infinite_sum<<setw(32);
        cout<< infinite_sum - euler_transform_sum(func43,interp,1,1000)<<setw(30);
        cout<< infinite_sum - euler_transform_sum(func43,interp,1,pow(10,9))<<setw(30);
        cout<<endl;
        cout<<"********************************************************"<<endl;

    //sum s5
        nop=1;
        cout<<"SUM 5"<<endl;
        cout<<"ACTUAL VALUE OF THE SUM:     "<<1.5*log(2)<<endl<<endl; 
        cout<<"CALCULATED VALUE:            "<<euler_transform_sum(func5,interp,nop,0);
        cout<<endl<<endl;   
        cout<<"********************************************************"<<endl; 

    //sum s6
        cout<<"SUM 6"<<endl;
        cout<<"ACTUAL VALUE OF THE SUM:     "<<0.5*log(2)<<endl<<endl; 
        cout<<"CALCULATED VALUE:            "<<euler_transform_sum(func6,interp,nop,0);
        cout<<endl<<endl;   
        cout<<"********************************************************"<<endl;

    return 0;   
}

