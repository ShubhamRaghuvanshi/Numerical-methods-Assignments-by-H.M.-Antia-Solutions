#include<iostream>
using namespace std;

double func11(double x)
{
    return 2*sin(x)-x;
}

double func12(double x)
{
    return 10*sin(x)-x;
}

double func13(double x)
{
    return 20*sin(x)-x;
}

double func14(double x)
{
    return 20.3959*sin(x)-x;
}

double func2(double x)
{
    return x-tan(x);
}

double func3(double x)
{
    return (x*x*x*x*x*x - 9.2*x*x*x*x*x + 34.45*x*x*x*x  - 66.914*x*x*x + 70.684*x*x -38.168*x + 8.112 + 0.01234*log(x) );
}

double func4(double x)
{
    double term=1;
        int i=1;
        double sum =1,temp=10;      
        do{
          term *= -(x*x/4)/(i*i);
          sum+=term;
          if(abs(sum-temp)<1e-10)
            break;
          temp = sum;
        i++; 
        }while(true);
        return sum;
}

double bisect(double (*func)(double),double x1,double x2,int niter,double aeps)
{
    int i;     
    double f1,f2,f3;
    for (i=0;i<niter;i++)
    {
        f1 = func(x1);
        f2 = func(x2);
        f3 = func((x1+x2)/2);

        if(abs(x1-x2)<aeps)
            break;

        if(f1*f3>0)
            x1 = (x1+x2)/2;
        if(f2*f3>0)
            x2 = (x1+x2)/2;
     }   
    return x1;
}



void bisection( double (*func)(double),double a,double b,int nop,double aeps)
{
    cout.precision(10);
    double h=(b-a)/nop,x1=a,x2=a+h,x;
    int root=1;

    for(int i=0;i<nop;i++)
    {   
        x1 = x1+h;
        x2 = x1+h; 
        if(func(x1)*func(x2)>0)
            continue;
        else
        {
            x = bisect(func,x1,x2,1000,aeps);
                if(abs(func(x))<1e-4)
                { 
                cout<<setw(5)<<"ROOT "<<root<<" = "<<x<<setw(30)<<"FUNCTIONAL VALUE :"<<setw(10)<<func(x)<<endl; 
                root = root+1;         
            }            
        }
  }
}










