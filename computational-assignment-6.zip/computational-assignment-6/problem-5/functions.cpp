#include<iostream>
#include<iomanip>
#include<math.h>

using namespace std;

double func(double x, double y ,double l, int n)
{
    switch (n)
    {
        case 1: return -y*y;
        case 2: return (10.0*y +15.0*exp(-5.0*x) );
        case 3: return (l*(y- x*x*x) + 3*x*x );
    }
}

double func2(double x , double y , double v ,double n,  int q )
{
    switch (q)
    {
        case 1: return ( (n*n/(x*x)-1)*y -v/x  );       
        case 2: return (  2*x*v - n*(n+1)*y  )/(1-x*x);
    }

}

// THEORETICAL SOLUTINOS
double sol(double x , double l , int n)
{
    switch (n)
    {
        case 1: return 1.0/(1+x);
        case 2: return ( 2*exp(10.0*x) -exp(-5.0*x) );
        case 3: return -exp(-5.0*x);
        case 4: return x*x*x;
        case 5:{    
                    double temp=pow(x/2,l), sum=0.0,sumprev=0.0 ,k=1.0;
                    while(true)
                    {   
                        sum = sum + temp;
                         if(abs(sum-sumprev)<1e-15)
                            return sum;
                        sumprev = sum;
                        temp = -x*x/(4.0*k*(l+k))*temp;
                        k++;                    
                       
                    }
               }
        case(6) :return (5*x*x*x - 3*x)/2.0;
        case(7) :return (231.0*x*x*x*x*x*x - 315.0*x*x*x*x + 105.0*x*x - 5.0)/16.0;
        case(8) :return (429.0*x*x*x*x*x*x*x - 693.0*x*x*x*x*x + 315.0*x*x*x - 35.0*x)/16.0;
    }
}

void rungekutta( double(f(double,double,double,int)), double(sol(double, double , int))  ,double l, double y0 ,double t0 , double t1, int nop ,int ques,int ans)
{
    double k1,k2,k3,k4,h,y,x=t0, s,d;
    
    h = (t1-t0)/double(nop);
    y =y0;
    d = double(nop)/10.0;

    cout<<"NUMBER OF POINTS FOR ALL THE VALUES :"<<nop<<endl;
    cout<<"CALCULATED"<<setw(20)<<"THEORETICAL"<<setw(21)<<"RELATIVE ERROR"<<setw(18)<<"t"<<endl<<endl;
    for(int i=1;i<=nop;i++)
    {
        k1 = f(x,y,l,ques) *h ;   
        k2 = h* f(x + h/2.0  , y + k1/2.0,l,ques);
        k3 = h* f(x + h/2.0  , y + k2/2.0,l,ques);
        k4 = h* f(x + h      , y + k3,l,ques);
        y = (k1+2.0*k2+2.0*k3+k4)/6.0 +y;
        x = x+h; 
        if(i%int(d)==0){
               s = sol(x,l,ans);
               cout<<setw(10)<<y<<setw(20)<<s<<setw(20)<<abs(y-s)/s<<setw(20)<<x<<endl;
        }
    }
       s = sol(x,l,ans);
    cout<<setw(10)<<y<<setw(20)<<s<<setw(20)<<abs(y-s)/s<<setw(20)<<x<<endl;       
   cout<<"**********************************************************"<<endl;
}

//RUNGE KUTTA FOR 2ND ORDER DIFF EQ
void rungekutta2( double (f(double,double,double,double,int)) ,double t0, double t1, int nop, double y0, double v0, double n,int qu,int ans)
{
    double k1=0,k2=0,k3=0,k4=0;
    double f1=0,f2=0,f3=0,f4=0;
    double h = (t1-t0)/double(nop),x=t0,y=y0,v=v0;
    double d = double(nop)/10.0,s;

    for(int i=1;i<=nop;i++)
    {
        k1=h*v;
        f1=h*f(x,y,v,n,qu);

        k2=h*(v+(f1/2.0 ));
        f2=h*f(x+(h/2.0),y+(k1/2.0),v+(f1/2.0),n,qu);

        k3=h*(v+(f2/2.0));
        f3=h*f(x+(h/2.0),y+(k2/2.0),v+(f2/2.0),n,qu);

        k4=h*(v+f3);
        f4=h*f(x+h,y+k3,v+f3,n,qu);

        v=v+(f1+2.0*f2+2.0*f3+f4)/6.0;

        y=y+(k1+2.0*k2+2.0*k3+k4)/6.0;

        x=x+h;
        if(i%int(d)==0){
               s = sol(x,n,ans);
               cout<<setw(10)<<y<<setw(20)<<s<<setw(20)<<abs(y-s)/s<<setw(20)<<x<<endl;
        }
      
    }
           s = sol(x,n,ans);
           cout<<setw(10)<<y<<setw(20)<<s<<setw(20)<<abs(y-s)/s<<setw(20)<<x<<endl;
       cout<<"**********************************************************"<<endl;
 
}













