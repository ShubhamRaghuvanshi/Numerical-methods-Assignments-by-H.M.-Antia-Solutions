#include<iostream>
#include<time.h>
using namespace std;

int main(){

	int ea,eb,a[4],b[4],carry,temp;	
	srand(time(NULL)); 
	
	for(int k=0;k<10;k++)
	{
		//initializing the variables of the problem
		carry=0;
		a[0]=rand()%9+1;
		b[0]=rand()%9+1;
		ea = rand()%10-rand()%10;
		eb = rand()%10-rand()%10;
	
		for(int i=1;i<4;i++)
		{
			a[i]=rand()%10;
			b[i]=rand()%10; 
		}

		/*the program needs number b<=a
		so we interchange the two if b>a */
		if(eb>ea)
		{
			temp=eb;
			eb=ea;
			ea = temp;
		
			for (int i=0;i<4;i++)
			{
				temp = b[i];
				b[i]=a[i];
				a[i]=temp;
			}
		}
	
		//printing out the numbers in the required form

		cout<<"number b = 0.";
		for (int j=0;j<4;j++)
			cout<<b[j];
		cout<<" E"<<eb<<"	";

		cout<<"number a = 0.";
		for (int j =0;j<4;j++)
			cout<<a[j];
		cout<<" E"<<ea<<"	";

		//if the exponent differ by more than 4,bigger number is the sum itself
		if(ea-eb<4) 		
		{
			for(int j=0;eb<ea;j++)  //making the exponents equal by right shift
	 		{  
				for(int i=3;i>0;i--)
					b[i]=b[i-1];
				b[j]=0;
				if(j>3)
				{
						break;	
				}
				eb++;		
			}

			for(int i=3;i>=0;i--) //adding the numbers digit by digit
			{
				a[i]=b[i]+a[i]+carry;
				if(a[i]>=10)
				{
					a[i]=a[i]%10;
					carry=1;	
				}
				else
					carry=0;

			}		
		}//if(eb-ea<=4)

		//printing out the sum
		if(carry ==0)
		{
			cout<<"sum c = 0.";
			for (int j=0;j<4-carry;j++)
				cout<<a[j];
			cout<<" E"<<ea+carry<<endl;
		}

		else
		{
			cout<<"sum c = 0."<<carry;
			for (int j=0;j<4-carry;j++)
				cout<<a[j];
			cout<<" E"<<ea+carry<<endl;

		}
	
	}//for(int k=0;k<100;k++)
	return 0;
}
