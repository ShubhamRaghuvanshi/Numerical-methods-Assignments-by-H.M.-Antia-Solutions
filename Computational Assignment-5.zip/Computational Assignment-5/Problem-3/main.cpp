#include<iostream>
#include<iomanip>
#include<math.h>
#include"functions.cpp"
using namespace std;

int main()
{
    double root[20],a;
    int rootcount;

    cout<<"PART A"<<endl;
    for(int j=0;j<2;j++)
    {
        if(j==0) a =1;
        if(j==1) a=0.1;     
        cout<<"FOR a = "<<a<<endl;
        rootcount = bisection( func1, 0, 1, a,32, 1e-13,root);
        for(int i=0;i<rootcount;i++)
            cout<<"REAL ROOT "<<i+1<<" {x,y} : {"<<tan(root[i])<<" ,"<<root[i]<<" } "<<endl;
        cout<<"*************************************************************************"<<endl;
    }

    cout<<"PART B"<<endl;   
    double x[2] = {2,-0.3};

      newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,1000,2);
       cout<<x[0]<<"   "<<x[1]<<endl;    
         
        x[0] = 4; x[1] = -0.1;
        newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,50,2);
        cout<<x[0]<<"   "<<x[1]<<endl;    

        x[0] = 8.1; x[1]=-0.2;
        newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,1000,16);
        cout<<x[0]<<"   "<<x[1]<<endl;    
     
        x[0] = 10; x[1]=-0.2;
        newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,1000,8);
        cout<<x[0]<<"   "<<x[1]<<endl;    
            
        x[0] = 14; x[1]=-0.2;
        newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,1000,2);
        cout<<x[0]<<"   "<<x[1]<<endl;     

        x[0] = 16; x[1]=-0.12;
        newton(func21,func22,dxfunc21,dyfunc21,dxfunc22,dyfunc22,x,1000,2);
        cout<<x[0]<<"   "<<x[1]<<endl;   
   

return 0;
}
