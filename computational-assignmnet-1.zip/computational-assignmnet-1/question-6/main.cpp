#include<iostream>
#include<iomanip>
#include<string>
#include<sstream>
using namespace std;
 int main()
 { 
	float x,sum,str;
	int i,k;

	cout<<"THREE DIGIT ARITHEMATC"<<endl;
//STARTING OF PART a
	sum=0;	
	for(i=1;;i++)
	{	
		stringstream inverse,summation;
		inverse.precision(3);
		summation.precision(3);	
		
		str= 1/float(i);
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
	
		summation<<sum;
		summation>>sum;		
			
		if(sum-x==0)
			break;
		cout<<scientific;
	}
	cout<<endl;
	cout<<"FOR THE FORWARD SUMMATION STARTING FROM 0:"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i<<endl;
	cout<<"************************************"<<endl<<endl;
//END OF PART a
	
//START OF PART b
	sum=0;
	for(k=i-1;k>0;k--)
	{	
		stringstream inverse,summation;
		inverse.precision(3);
		summation.precision(3);	
		
		str= 1/float(k);
			
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
		summation<<sum;
		summation>>sum;		
		
	}
	
	cout<<"FOR THE BACKWARD SUMMATION STARTING FROM "<<i<<":"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i-k<<endl;
	cout<<"************************************"<<endl<<endl;

//END OF PART b

//START OF PART c
	sum=0;
	for(k=10*i;k>0;k--)
	{	
		stringstream inverse,summation;
		inverse.precision(3);
		summation.precision(3);	
		
		str= 1/float(k);
			
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
		summation<<sum;
		summation>>sum;		
		
	}
	
	cout<<"FOR THE BACKWARD SUMMATION STARTING FROM "<<10*i<<":"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i-k<<endl;
	cout<<"************************************"<<endl<<endl;
//END OF PART c

cout<<" FIVE DIGIT ARITHEMATIC"<<endl;	


//STARTING OF PART a
	sum=0;	
	for(i=1;;i++)
	{	
		stringstream inverse,summation;
		inverse.precision(5);
		summation.precision(5);	
		
		str= 1/float(i);
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
	
		summation<<sum;
		summation>>sum;		
			
		if(sum-x==0)
			break;
		cout<<scientific;
	}
	cout<<endl;
	cout<<"FOR THE FORWARD SUMMATION STARTING FROM 0:"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i<<endl;
	cout<<"************************************"<<endl<<endl;
//END OF PART a
	
//START OF PART b
	sum=0;
	for(k=i-1;k>0;k--)
	{	
		stringstream inverse,summation;
		inverse.precision(5);
		summation.precision(5);	
		
		str= 1/float(k);
			
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
		summation<<sum;
		summation>>sum;		
		
	}
	
	cout<<"FOR THE BACKWARD SUMMATION STARTING FROM "<<i<<":"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i-k<<endl;
	cout<<"************************************"<<endl<<endl;

//END OF PART b

//START OF PART c
	sum=0;
	for(k=10*i;k>0;k--)
	{	
		stringstream inverse,summation;
		inverse.precision(5);
		summation.precision(5);	
		
		str= 1/float(k);
			
		inverse<<str;
		inverse>>str;
		x=sum;	
		sum =sum+str;	
		summation<<sum;
		summation>>sum;		
		
	}
	
	cout<<"FOR THE BACKWARD SUMMATION STARTING FROM "<<10*i<<":"<<endl;	
	cout<<"************************************"<<endl;
	cout<<"SUM = "<<sum<<"  AND n =  "<<i-k<<endl;
	cout<<"************************************"<<endl<<endl;
//END OF PART c










	return 0;
}

