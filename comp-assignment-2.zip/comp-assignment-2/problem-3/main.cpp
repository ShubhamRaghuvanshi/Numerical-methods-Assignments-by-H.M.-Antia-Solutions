#include<iostream>
#include<iomanip>
#include<time.h>
#include<math.h>
#include<stdlib.h>
#include "MatrixOperarions.h"


using namespace std;

int main()
{
	int order;
	

	order=4;

	
	
	matrix A(order),sigma(order),U(order),V(order),b(order,1); 
	
	A.setcomp(0,0,3); A.setcomp(0,1,4);A.setcomp(0,2,-5); A.setcomp(0,3,-1);
	A.setcomp(1,0,2); A.setcomp(1,1,3);A.setcomp(1,2,-1); A.setcomp(1,3,-3);
	A.setcomp(2,0,4); A.setcomp(2,1,5);A.setcomp(2,2,-9);A.setcomp(2,3,6);
	A.setcomp(3,0,1); A.setcomp(3,1,1);A.setcomp(3,2,-4); A.setcomp(3,3,-2);	
	
	b.setcomp(0,0,12); b.setcomp(1,0,1); b.setcomp(2,0,28); b.setcomp(3,0,7);
	

	cout<<"A :"<<endl;
	A.display();
	
	A.svd(A,U,sigma,V,b);
	b.setcomp(3,0,5);
	A.svd(A,U,sigma,V,b);
	
	cout<<"END OF PART A"<<endl;	
	cout<<"##############################################################################"<<endl;

	return 0;
}




