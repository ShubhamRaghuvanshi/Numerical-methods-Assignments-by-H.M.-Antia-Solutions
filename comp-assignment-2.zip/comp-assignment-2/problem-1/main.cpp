#include<iostream>
#include<iomanip>
#include"function.cpp"
using namespace std;


int main()
{
  
  int d=4;
   double a[][d] = {{0.000007143,0,0,0},{0.6262,0.000007355,0,0},{0.4923,0.2123,0.000002534,0},        {0.8017,0.6123,0.7165,0.000004133}};

  double b[] = {0.000009245,0.3763,0.6087,0.4306},*x,sum;

//start -part a 

  cout<<"START PART a"<<endl<<endl;
  display(*a,d,d);
  cout<<"SOLUTION FOR SYSTEM OF EQUATION (fron x1 to x4):"<<endl;	
  x = forward_substitution(*a,b,d);
  showvector(x,d);
  
  for (int i=0;i<d;i++)
  { 
    sum=0;
    for(int j=0;j<=i;j++)
    {
      sum = sum + a[i][j];
    } 
    b[i] = sum;
  }	
  
  cout<<"SOLUTION FOR TRIAL VECTOR FOR FIRST SYSTEM (from x1 to x4):"<<endl;	
  x = forward_substitution(*a,b,d);	
  showvector(x,d);
  cout<<"END PART a"<<endl;	
  cout<<"********************************************************"<<endl;

//end part a
 
//start part b
   
  cout<<"START PART b"<<endl<<endl;
  int row=5,col=6;
  double m[][col] =
{{0.9888480,0.6592320,0.4944240,0.3955392,0.3296160,0.60345}, {0.6592320,0.4944240,0.3955392,0.3296160,0.2825280,0.65434},{0.4944240,0.3955392,0.3296160,0.2825280,0.2472120,0.78645},{0.3955392,0.3296160,0.2825280,0.2472120,0.2197440,0.95467},{0.3296160,0.2825280,0.2472120,0.2197440,0.1977587,0.34527}};

 double c[]= {0.60345,0.65434,0.78645,0.95467,0.34527},*sol;	
  
  cout<<"THE GIVEN SYSTEM OF EQUATIONS IN [A|B] FORM IS:"<<endl;
  display(*m,row,col);
  
  cout<<"THE CORRESPODING SOLUTION OF THE EQUATIONS IS (from x1 to x5):"<<endl;
  sol =gauss(*m,row,col);
  showvector(sol,row);
  cout<<"END PART b"<<endl;	
  cout<<"********************************************************"<<endl;
//end part b

//start part c
  cout<<"START PART c"<<endl<<endl;
  row=2;
  col=3;
  int n[]={5,10,20,50};
  double f[2][3] ;
  
  for(int i=0;i<4;i++)
  {
    f[0][0] = fibonacci(n[i]);	
    f[0][1] = fibonacci(n[i]+1);
    f[0][2] = fibonacci(n[i]+2);
    f[1][0] = f[0][1];
    f[1][1] = f[0][2];
    f[1][2] = fibonacci(n[i]+3);
  
    cout<<"THE GIVEN SYSTEM OF EQUATIONS IN [A|B] FORM IS:"<<endl;
    display(*f,row,col);
  
    cout<<"THE CORRESPODING SOLUTION OF THE EQUATIONS IS (from x1 to x2):"<<endl;
    sol = gauss(*f,row,col);
    showvector(sol,row); 
  }
  
  cout<<"END PART c"<<endl;	
  cout<<"********************************************************"<<endl; 

//end part c
return 0;

}






















