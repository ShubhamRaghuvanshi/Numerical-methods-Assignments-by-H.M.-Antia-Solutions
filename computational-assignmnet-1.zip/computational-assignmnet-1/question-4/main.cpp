#include<iostream>
#include<math.h>

using namespace std;


float exponent(float x)
{
	float sum=1,a0=1,a1,sign=1,psum;
	
	if(x<0)
	{
		x=-x;	
		sign =-1;	
	}
	for (int n=1;;n++)
	{	
		a1 = (x/n)*a0;		
		sum = a1+sum;		
		a0=a1;
		if(psum-sum==0)
			break;		
		psum=sum;
	}	
	if(sign==1)	
	return sum;
	else
	return (1/sum);
}

float sinosoid(float x)

{
	
	float sum=x,a0=x,a1,sign=1,psum;
	
	if(x<0)
	{
		x=-x;	
		sign =-1;	
	}
	for (int n=1;;n++)
	{	
		a1 = -(x*x*a0)/((2*n+1)*(2*n));
		sum = a1+sum;		
		a0=a1;
		if(psum-sum==0)
			break;		
		psum=sum;
	}	
	
	if(sign==1)	
	return sum;
	else
	return (-sum);
}


int main()
{
	cout.precision(8);	
	float sum;
	float x[] = {-50,-20,-5,-1,-0.1,0.1,1,5,20,50};
	float y[] = {3.14,3.1416,3.141593};


	cout<<endl<<"						********EXPONENT***********"	<<endl;
	for(int i=0;i<10;i++)
	{	
		sum = exponent(x[i]);
		cout<<endl<<"*****************************"<<endl;
		cout<<"FOR x = "<<x[i]<<""<<endl;
		cout<<"CALCULATED EXP     =   "<<sum<<endl;
		cout<<"SYSTEM EXP         =   "<<exp(x[i])<<endl;
		cout<<"ERROR              =   "<<abs(exp(x[i])-sum)<<endl;
		cout<<"PERCENTAGE ERROR   =   "<<abs(1-exp(x[i])/sum)<<endl;	
		cout<<endl<<"*****************************"<<endl;
	} 

	cout<<endl<<"					************SINOSOID**************"<<endl;
	for(int i=0;i<3;i++)
	{	
		sum = sinosoid(y[i]);
		cout<<endl<<"*****************************"<<endl;
		cout<<"FOR x = "<<y[i]<<""<<endl;
		cout<<"CALCULATED SIN     =   "<<sum<<endl;
		cout<<"SYSTEM SIN         =   "<<sin(y[i])<<endl;
		cout<<"ERROR              =   "<<abs(sin(y[i])-sum)<<endl;
		cout<<"PERCENTAGE ERROR   =   "<<abs(1-sin(y[i])/sum)<<endl;	
		cout<<endl<<"*****************************"<<endl;
	}

	


return 0;
}

