#include<iostream>
#include<iomanip>
#include"functions.cpp"

using namespace std;

int main()
{
    cout.precision(15); 
    int N=21,i=0,n[]={14,4}; 
    double w[N][N] ={0},l,u,temp,guess[N],m;

    initialize(*w,N);
    
    l = w[i][i] -abs( w[i+1][i] );
    u = w[i][i] +abs( w[i+1][i] );
    for( i=1;i<N;i++)
    {      
        if (i==N-1)
            temp = abs( w[i][i-1] ) ;
        else
             temp =abs( w[i][i-1] )+ abs( w[i+1][i] );
        if(l> w[i][i]-temp)
        l=w[i][i]-temp;  
        if(u<w[i][i]+temp)
        u =w[i][i]+ temp;
    }
    cout<<"EIGEN VALUES LIE IN THE RANGE {"<<l<<" , "<<u<<" }"<<endl<<endl;
  
for(int i=0;i<2;i++)
{
    sturm(*w,N,l,u,guess,n[i],m,1e-14);
    cout<<n[i]<<"th EIGENVALUE IS :"<<setw(30)<<m<<endl;
    cout<<endl<<"THE CORRESPONDING EIGENVECTOR IS :"<<endl;   
   for(int i=0;i<N;i++)
    cout<<setw(50)<<guess[i]<<endl;
    cout<<endl<<"***************************************************"<<endl;
  
}


return 0;
}
